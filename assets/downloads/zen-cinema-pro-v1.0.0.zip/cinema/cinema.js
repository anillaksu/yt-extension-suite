/**
 * Zen Cinema - Nocookie Dark Mode Theater Controller
 * Pure HTML5 IFrame + postMessage API (100% Manifest V3 CSP Compliant)
 */
(function() {
  'use strict';

  // State
  let currentVideoId = '';
  let isLoopEnabled = false;
  let currentSpeed = 1.0;
  let currentTime = 0;
  let playerState = -1;
  let notes = [];

  // DOM Elements
  const cinemaIframe = document.getElementById('cinemaIframe');
  const videoTitleEl = document.getElementById('videoTitle');
  const channelNameEl = document.getElementById('channelName');
  const ambientGlow = document.getElementById('ambientGlow');
  const toggleGlowBtn = document.getElementById('toggleGlow');
  const toggleLightsBtn = document.getElementById('toggleLights');
  const toggleNotesBtn = document.getElementById('toggleNotes');
  const notesPanel = document.getElementById('notesPanel');
  const closeNotesBtn = document.getElementById('closeNotes');
  const backToYtBtn = document.getElementById('backToYt');
  const openOriginalBtn = document.getElementById('openOriginal');
  const btnBackward = document.getElementById('btnBackward');
  const btnForward = document.getElementById('btnForward');
  const btnLoop = document.getElementById('btnLoop');
  const loopStatus = document.getElementById('loopStatus');
  const btnFullscreen = document.getElementById('btnFullscreen');
  const playerWrapper = document.getElementById('playerWrapper');
  const speedBtns = document.querySelectorAll('.speed-btn');
  const noteInput = document.getElementById('noteInput');
  const saveNoteBtn = document.getElementById('saveNoteBtn');
  const notesList = document.getElementById('notesList');
  const emptyNotesMsg = document.getElementById('emptyNotesMsg');
  const exportNotesBtn = document.getElementById('exportNotesBtn');
  const clearNotesBtn = document.getElementById('clearNotesBtn');
  const currentTimestampBadge = document.getElementById('currentTimestampBadge');
  const btnAddNoteQuick = document.getElementById('btnAddNoteQuick');
  const btnOpenModal = document.getElementById('btnOpenModal');
  const urlModal = document.getElementById('urlModal');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const cancelModalBtn = document.getElementById('cancelModalBtn');
  const loadVideoBtn = document.getElementById('loadVideoBtn');
  const manualUrlInput = document.getElementById('manualUrlInput');

  // Extract video ID from URL query parameters
  function extractVideoId() {
    const params = new URLSearchParams(window.location.search);
    const v = params.get('v') || params.get('videoId');
    if (v) return cleanVideoId(v);

    // Default fallback if opened directly without query
    return 'dQw4w9WgXcQ';
  }

  function cleanVideoId(input) {
    if (!input) return '';
    input = input.trim();
    if (input.includes('youtu.be/')) {
      const parts = input.split('youtu.be/');
      return parts[1].split(/[?#&]/)[0];
    }
    if (input.includes('watch?v=') || input.includes('watch?')) {
      const match = input.match(/[?&]v=([^&#]+)/);
      if (match) return match[1];
    }
    if (input.includes('embed/')) {
      const parts = input.split('embed/');
      return parts[1].split(/[?#&]/)[0];
    }
    return input.replace(/[^a-zA-Z0-9_-]/g, '');
  }

  // Format seconds into MM:SS or HH:MM:SS
  function formatTime(seconds) {
    seconds = Math.floor(seconds || 0);
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const pad = (num) => num.toString().padStart(2, '0');
    if (hrs > 0) {
      return `${hrs}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  }

  // Fetch oEmbed video metadata
  async function fetchVideoInfo(videoId) {
    try {
      const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
      const res = await fetch(oembedUrl);
      if (res.ok) {
        const data = await res.json();
        videoTitleEl.textContent = data.title || 'YouTube Video';
        channelNameEl.textContent = data.author_name || 'YouTube Nocookie Safe Stream';
        document.title = `${data.title || 'Video'} - Zen Cinema`;
        return;
      }
    } catch (e) {}

    videoTitleEl.textContent = `YouTube Video (${videoId})`;
    document.title = `Zen Cinema - ${videoId}`;
  }

  // Send control command to YouTube IFrame via standard postMessage protocol
  function sendPlayerCommand(func, args = []) {
    if (cinemaIframe && cinemaIframe.contentWindow) {
      cinemaIframe.contentWindow.postMessage(JSON.stringify({
        event: 'command',
        func: func,
        args: args
      }), '*');
    }
  }

  // Handle incoming messages from YouTube IFrame
  window.addEventListener('message', (event) => {
    if (!event.data) return;
    let data = event.data;
    if (typeof data === 'string') {
      try { data = JSON.parse(data); } catch (e) { return; }
    }
    if (data && data.event === 'infoDelivery' && data.info) {
      if (typeof data.info.currentTime === 'number') {
        currentTime = data.info.currentTime;
        currentTimestampBadge.textContent = formatTime(currentTime);
      }
      if (typeof data.info.playerState === 'number') {
        playerState = data.info.playerState;
        // playerState 0 is ENDED
        if (playerState === 0 && isLoopEnabled) {
          sendPlayerCommand('seekTo', [0, true]);
          sendPlayerCommand('playVideo');
        }
      }
    }
  });

  // Load and render saved notes for this video
  function loadNotes() {
    try {
      const saved = localStorage.getItem(`zen_notes_${currentVideoId}`);
      notes = saved ? JSON.parse(saved) : [];
    } catch (e) {
      notes = [];
    }
    renderNotes();
  }

  function saveNotes() {
    try {
      localStorage.setItem(`zen_notes_${currentVideoId}`, JSON.stringify(notes));
    } catch (e) {}
    renderNotes();
  }

  function renderNotes() {
    notesList.innerHTML = '';
    if (notes.length === 0) {
      emptyNotesMsg.style.display = 'block';
      notesList.appendChild(emptyNotesMsg);
      return;
    }
    emptyNotesMsg.style.display = 'none';

    notes.sort((a, b) => a.time - b.time);

    notes.forEach((item, index) => {
      const noteItem = document.createElement('div');
      noteItem.className = 'note-item';

      const timeBtn = document.createElement('button');
      timeBtn.className = 'note-time-btn';
      timeBtn.textContent = formatTime(item.time);
      timeBtn.title = 'Bu saniyeye git';
      timeBtn.addEventListener('click', () => {
        sendPlayerCommand('seekTo', [item.time, true]);
        sendPlayerCommand('playVideo');
      });

      const textEl = document.createElement('span');
      textEl.className = 'note-text';
      textEl.textContent = item.text;

      const delBtn = document.createElement('button');
      delBtn.className = 'note-delete-btn';
      delBtn.textContent = '✕';
      delBtn.title = 'Notu sil';
      delBtn.addEventListener('click', () => {
        notes.splice(index, 1);
        saveNotes();
      });

      noteItem.appendChild(timeBtn);
      noteItem.appendChild(textEl);
      noteItem.appendChild(delBtn);
      notesList.appendChild(noteItem);
    });
  }

  function addCurrentNote() {
    const text = noteInput.value.trim();
    if (!text) return;

    notes.push({
      id: Date.now(),
      time: Math.floor(currentTime),
      text: text
    });

    saveNotes();
    noteInput.value = '';
    noteInput.focus();
  }

  // Initialize Player
  function initPlayer(videoId) {
    currentVideoId = videoId;
    fetchVideoInfo(videoId);
    loadNotes();

    openOriginalBtn.onclick = () => {
      window.open(`https://www.youtube.com/watch?v=${currentVideoId}`, '_blank');
    };

    backToYtBtn.onclick = () => {
      window.location.href = `https://www.youtube.com/watch?v=${currentVideoId}`;
    };

    // Construct pure nocookie embed URL
    const embedUrl = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&enablejsapi=1&rel=0&modestbranding=1&iv_load_policy=3&playsinline=1`;
    cinemaIframe.src = embedUrl;

    cinemaIframe.onload = () => {
      // Handshake with YouTube IFrame
      sendPlayerCommand('listening');
      sendPlayerCommand('addEventListener', ['onStateChange']);
      sendPlayerCommand('setPlaybackRate', [currentSpeed]);
    };
  }

  // Setup Event Listeners
  function setupListeners() {
    // Quick jumps
    btnBackward.addEventListener('click', () => {
      sendPlayerCommand('seekTo', [Math.max(0, currentTime - 10), true]);
    });

    btnForward.addEventListener('click', () => {
      sendPlayerCommand('seekTo', [currentTime + 10, true]);
    });

    // Speed Controls
    speedBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        speedBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const speed = parseFloat(btn.dataset.speed);
        currentSpeed = speed;
        sendPlayerCommand('setPlaybackRate', [speed]);
      });
    });

    // Loop Toggle
    btnLoop.addEventListener('click', () => {
      isLoopEnabled = !isLoopEnabled;
      loopStatus.textContent = isLoopEnabled ? 'Açık' : 'Kapalı';
      btnLoop.classList.toggle('primary-ribbon', isLoopEnabled);
    });

    // Fullscreen
    btnFullscreen.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        playerWrapper.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    });

    // Ambient Glow Toggle
    toggleGlowBtn.addEventListener('click', () => {
      const isVisible = !ambientGlow.classList.contains('hidden');
      if (isVisible) {
        ambientGlow.classList.add('hidden');
        toggleGlowBtn.classList.remove('active');
      } else {
        ambientGlow.classList.remove('hidden');
        toggleGlowBtn.classList.add('active');
      }
    });

    // Cinema Lights Off
    toggleLightsBtn.addEventListener('click', () => {
      document.body.classList.toggle('lights-off');
      const isOff = document.body.classList.contains('lights-off');
      toggleLightsBtn.classList.toggle('active', isOff);
    });

    // Side Notes Toggle
    toggleNotesBtn.addEventListener('click', () => {
      notesPanel.classList.toggle('hidden');
      toggleNotesBtn.classList.toggle('active', !notesPanel.classList.contains('hidden'));
    });

    closeNotesBtn.addEventListener('click', () => {
      notesPanel.classList.add('hidden');
      toggleNotesBtn.classList.remove('active');
    });

    // Note Saving
    saveNoteBtn.addEventListener('click', addCurrentNote);
    noteInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        addCurrentNote();
      }
    });

    btnAddNoteQuick.addEventListener('click', () => {
      notesPanel.classList.remove('hidden');
      toggleNotesBtn.classList.add('active');
      noteInput.focus();
    });

    // Export Notes
    exportNotesBtn.addEventListener('click', () => {
      if (notes.length === 0) return;
      let md = `# Zen Cinema Notları: ${videoTitleEl.textContent}\n`;
      md += `Video Bağlantısı: https://www.youtube.com/watch?v=${currentVideoId}\n\n`;
      notes.forEach(n => {
        md += `- **[${formatTime(n.time)}]** ${n.text}\n`;
      });
      navigator.clipboard.writeText(md).then(() => {
        const origText = exportNotesBtn.textContent;
        exportNotesBtn.textContent = '✅ Kopyalandı!';
        setTimeout(() => { exportNotesBtn.textContent = origText; }, 2000);
      });
    });

    // Clear Notes
    clearNotesBtn.addEventListener('click', () => {
      if (confirm('Bu video için tüm notları silmek istediğinize emin misiniz?')) {
        notes = [];
        saveNotes();
      }
    });

    // URL Changer Modal
    btnOpenModal.addEventListener('click', () => {
      urlModal.classList.remove('hidden');
      manualUrlInput.focus();
    });

    closeModalBtn.addEventListener('click', () => {
      urlModal.classList.add('hidden');
    });

    cancelModalBtn.addEventListener('click', () => {
      urlModal.classList.add('hidden');
    });

    loadVideoBtn.addEventListener('click', () => {
      const raw = manualUrlInput.value;
      const newId = cleanVideoId(raw);
      if (newId) {
        urlModal.classList.add('hidden');
        manualUrlInput.value = '';
        window.history.pushState({}, '', `?v=${newId}`);
        initPlayer(newId);
      } else {
        alert('Lütfen geçerli bir YouTube video linki veya ID girin.');
      }
    });

    // Keyboard Shortcuts
    document.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

      if (e.key === 'f' || e.key === 'F') {
        btnFullscreen.click();
      } else if (e.key === 'n' || e.key === 'N') {
        toggleNotesBtn.click();
      } else if (e.key === 'a' || e.key === 'A') {
        toggleGlowBtn.click();
      } else if (e.key === 'l' || e.key === 'L') {
        toggleLightsBtn.click();
      } else if (e.key === 'j' || e.key === 'J' || e.key === 'ArrowLeft') {
        btnBackward.click();
      } else if (e.key === 'l' || e.key === 'L' || e.key === 'ArrowRight') {
        btnForward.click();
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        // Toggle play/pause
        if (playerState === 1) {
          sendPlayerCommand('pauseVideo');
        } else {
          sendPlayerCommand('playVideo');
        }
      }
    });
  }

  // Initialization
  document.addEventListener('DOMContentLoaded', () => {
    const videoId = extractVideoId();
    setupListeners();
    initPlayer(videoId);
  });
})();

/**
 * YouTube Media Player Accelerator - Background Service Worker
 * Manages device fingerprinting, license verification, and background synchronization.
 *
 * Faz 4: özel backend'e (yt-license-service) bağımlılık kaldırıldı.
 * clean-full-page-pdf-capture/extension/lib/license-validator.js'de kanıtlanan
 * desenle aynı: Polar'ın PUBLIC customer-portal validate ucu — gizli
 * token gerektirmez, istemcide bulunması güvenlidir (organization_id
 * gizli değildir). Bu değişiklik olmadan backend emekliye ayrılamazdı;
 * bu uzantı tek gerçek bağımlı taraftı (clean_capture zaten Polar'a
 * doğrudan bağlıydı).
 */

const POLAR_VALIDATE_ENDPOINT = 'https://api.polar.sh/v1/customer-portal/license-keys/validate';
const POLAR_ORGANIZATION_ID = '450fc977-6d1a-4af9-b6b7-a3313b344595';

// Bu eklentiyi açan benefit'ler: kendi ürünü VEYA bundle.
// Gizli değildir (istemcide bulunur); kaynak catalog/registry.json.
const BENEFIT_YT_ACCELERATOR = '2e04258e-4fa2-4a93-9c7d-67429447ae08';
const BENEFIT_BUNDLE_SUITE = 'f9db8acf-ed10-4ce4-b084-b9723823be8c';
const ACCEPTED_BENEFIT_IDS = [BENEFIT_YT_ACCELERATOR, BENEFIT_BUNDLE_SUITE];
const OFFLINE_GRACE_DAYS = 7;

// Generate or retrieve persistent per-install device ID (rastgele — gercek
// donanim parmak izi degil; bkz. suite-web-portal claims-policy.json'daki
// "Cihaz Bazli Lisans Aktivasyonu" duzeltmesi).
async function getOrCreateDeviceId() {
  const result = await chrome.storage.local.get('hardwareId');
  if (result.hardwareId) {
    return result.hardwareId;
  }
  const newId = 'dev_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  await chrome.storage.local.set({ hardwareId: newId });
  return newId;
}

// Polar'ın ham API hata metinleri kullanıcıya GÖSTERİLMEZ. Ölçüldü:
// bilinmeyen anahtarda Polar 404 {"error":"ResourceNotFound","detail":"Not found"}
// döndürüyor — yani anahtarı yanlış yazan müşteri ekranda İngilizce "Not found"
// görüyordu. Aşağıdaki eşleyici duruma göre anlaşılır mesaj verir.
function polarHataMesaji(response, data) {
  const status = response?.status;
  if (status === 404 || data?.error === 'ResourceNotFound') {
    return 'Geçersiz lisans anahtarı. Satın alırken size gönderilen anahtarı kopyala-yapıştır ile girdiğinizden emin olun.';
  }
  if (status === 429) {
    return 'Çok fazla deneme yapıldı. Lütfen birkaç dakika sonra tekrar deneyin.';
  }
  if (status >= 500) {
    return 'Lisans doğrulama servisine şu anda ulaşılamıyor. Lütfen birazdan tekrar deneyin.';
  }
  return data?.detail || data?.error || 'Geçersiz lisans anahtarı.';
}

// Check license directly against Polar (no custom backend involved)
async function verifyLicenseWithServer(licenseKey) {
  const key = (licenseKey || '').trim().toUpperCase();
  if (!key) {
    return { success: false, error: 'Lisans anahtarı boş olamaz.' };
  }

  try {
    const response = await fetch(POLAR_VALIDATE_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        key,
        organization_id: POLAR_ORGANIZATION_ID
      })
    });

    const data = await response.json();

    // GELİR AÇIĞI DÜZELTMESİ (2026-09-03, gerçek satın alma takibiyle bulundu):
    // Önceden yalnızca status kontrol ediliyordu. Polar organizasyondaki
    // HERHANGİ bir geçerli anahtar için 'granted' döner — ürün ayrımı
    // `benefit_id` alanındadır. Yani 11.99$'lık Clean Capture anahtarı bu
    // 19.99$'lık ürünü de açıyordu (iki gerçek anahtarla canlı kanıtlandı).
    // `|| data.id` de kaldırıldı: status uygun değilken bile yanıtta id
    // bulunmasını yeterli sayan, durum kontrolünü fiilen iptal eden bir kalıptı.
    const statusOk = data.status === 'granted' || data.status === 'active';
    const benefitOk = ACCEPTED_BENEFIT_IDS.includes(data.benefit_id);

    if (response.ok && statusOk && !benefitOk) {
      await chrome.storage.local.set({ isLicensed: false, licenseError: 'WRONG_PRODUCT' });
      return { success: false, error: 'Bu lisans anahtarı başka bir ürüne ait. YouTube Player Accelerator Pro veya Ultimate Suite Bundle anahtarı gerekli.' };
    }

    if (response.ok && statusOk && benefitOk) {
      await chrome.storage.local.set({
        isLicensed: true,
        licenseKey: key,
        customerEmail: data.customer?.email || null,
        expiresAt: data.expires_at || null,
        lastVerifiedAt: new Date().toISOString(),
        features: {
          bannerCleaner: true,
          antiAdblockShield: true,
          streamSpeedSupressor: true
        }
      });
      return { success: true, data };
    } else {
      const mesaj = polarHataMesaji(response, data);
      await chrome.storage.local.set({ isLicensed: false, licenseError: mesaj });
      return { success: false, error: mesaj };
    }
  } catch (err) {
    console.error('[BACKGROUND] Polar doğrulama ağ hatası:', err);
    const existing = await chrome.storage.local.get(['isLicensed', 'licenseKey', 'lastVerifiedAt']);
    if (existing.isLicensed && existing.licenseKey === key && existing.lastVerifiedAt) {
      const lastCheck = new Date(existing.lastVerifiedAt).getTime();
      const elapsedDays = (Date.now() - lastCheck) / (1000 * 60 * 60 * 24);
      if (elapsedDays <= OFFLINE_GRACE_DAYS) {
        console.log(`[BACKGROUND] Offline Grace Mode Active (Day ${elapsedDays.toFixed(1)} / ${OFFLINE_GRACE_DAYS})`);
        return { success: true, offlineGrace: true, message: 'Çevrimdışı koruma modu devrede.' };
      }
    }
    return { success: false, error: 'Polar doğrulama sunucusuna bağlanılamadı. İnternet bağlantınızı kontrol ediniz.' };
  }
}

// On install / update
chrome.runtime.onInstalled.addListener(async (details) => {
  await getOrCreateDeviceId();

  const data = await chrome.storage.local.get(['isLicensed', 'isEnabled']);
  if (data.isLicensed === undefined) {
    await chrome.storage.local.set({
      isLicensed: false,
      isEnabled: true,
      features: {
        smartInterceptor: true,
        bannerCleaner: true,
        streamSpeedSupressor: true,
        antiAdblockShield: true
      }
    });
  }

  // Set up periodic verification alarm (every 24 hours)
  chrome.alarms.create('check_license_periodically', { periodInMinutes: 1440 });
});

// Periodic alarm handler
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'check_license_periodically') {
    const stored = await chrome.storage.local.get(['licenseKey']);
    if (stored.licenseKey) {
      await verifyLicenseWithServer(stored.licenseKey);
    }
  }
});

// Message listener from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'VERIFY_LICENSE') {
    verifyLicenseWithServer(request.licenseKey).then(sendResponse);
    return true; // Keep channel open for async response
  }
  if (request.action === 'GET_DEVICE_ID') {
    getOrCreateDeviceId().then(id => sendResponse({ hardwareId: id }));
    return true;
  }
});

/**
 * Zen Cinema — hoş geldin sayfası. Kısayolları burada denetir (Alt+C/N/S/T kartı yakar),
 * sonunda gerçek bir YouTube videosunda uygulamalı turu başlatır (content/tur.js).
 */
(function () {
  'use strict';
  const t = (k, y) => chrome.i18n.getMessage(k) || y || k;
  const mac = /Mac/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');
  const dil = (chrome.i18n.getUILanguage() || 'en').toLowerCase().startsWith('tr') ? 'tr' : 'en';
  const TUR_VIDEO = 'aircAruvnKk'; // 3Blue1Brown, "But what is a neural network?" — altyazılı, zaman damgalı yorumlu

  document.documentElement.lang = dil;
  document.title = 'Zen Cinema — ' + t('hgEtiket', 'Installed and ready');
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    let m = t(el.dataset.i18n, el.textContent);
    if (mac) m = m.replace(/Alt\s?\+\s?/g, '⌥ ');
    el.textContent = m;
  });
  if (mac) document.querySelectorAll('.alt-tus').forEach((k) => { k.textContent = '⌥'; });

  const gorsel = (n) => `img/${dil}/${n}.webp`;
  document.querySelectorAll('img[data-gorsel]').forEach((i) => { i.src = gorsel(i.dataset.gorsel); });

  // Açılış odağı: sahne büyüyerek belirir, sekme başlığı kısa süre işaretlenir.
  document.body.classList.add('acilis');
  const asilBaslik = document.title;
  let yanip = 0;
  const yanSon = setInterval(() => {
    document.title = (yanip++ % 2 === 0 ? '● ' : '') + asilBaslik;
    if (yanip > 5) { clearInterval(yanSon); document.title = asilBaslik; }
  }, 700);

  // Hareket kartları ↔ önizleme
  const onizleme = document.getElementById('onizleme');
  const kartlar = [...document.querySelectorAll('.hareket')];
  function sec(kart, parla) {
    kartlar.forEach((k) => k.classList.toggle('secili', k === kart));
    const yeni = gorsel(kart.dataset.gorsel);
    if (!onizleme.src.endsWith(yeni)) {
      onizleme.classList.add('gecis');
      setTimeout(() => { onizleme.src = yeni; onizleme.onload = () => onizleme.classList.remove('gecis'); }, 180);
    }
    if (parla) { kart.classList.remove('parla'); void kart.offsetWidth; kart.classList.add('parla'); }
  }
  kartlar.forEach((k) => k.addEventListener('click', () => sec(k, false)));

  // Bu sayfada kısayolları dene: tuş kapakları basılır, kart yanar.
  window.addEventListener('keydown', (e) => {
    if (!e.altKey || e.ctrlKey || e.metaKey) return;
    const kart = kartlar.find((k) => k.dataset.kod === e.code);
    if (!kart) return;
    e.preventDefault();
    sec(kart, true);
    kart.querySelectorAll('kbd').forEach((k) => k.classList.add('basili'));
    setTimeout(() => kart.querySelectorAll('kbd').forEach((k) => k.classList.remove('basili')), 260);
    if (window.innerWidth <= 900) kart.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });

  // Uygulamalı tur: içerik betiği bu kaydı görünce turu başlatır.
  document.querySelectorAll('[data-tur]').forEach((d) => d.addEventListener('click', async () => {
    await chrome.storage.local.set({ turBekliyor: { videoId: TUR_VIDEO, zaman: Date.now(), adim: 0 } });
    location.href = `https://www.youtube.com/watch?v=${TUR_VIDEO}`;
  }));
})();

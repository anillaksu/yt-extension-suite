/**
 * Zen Cinema — servis çalışanı.
 * Lisans: Polar (lib/license-validator.js; gizli token yok, 24 sa'te bir yeniden doğrulama, 7 gün çevrimdışı tolerans).
 * Defterler: metadata chrome.storage.local 'defterler', kareler IndexedDB (lib/depo.js).
 * Ücretsiz sınır burada uygulanır (lib/kurallar.js).
 */
importScripts('lib/license-validator.js', 'lib/kurallar.js', 'lib/depo.js');

const SATIN_AL_URL = 'https://buy.polar.sh/polar_cl_PSlObXBqmnn6MMU7VbiPUZoOznY7MwkBf85Cv0GvXDv';
const GUN_MS = 24 * 60 * 60 * 1000;
const dogrulayici = globalThis.licenseValidator;

// --- Lisans ---
async function proMu() {
  const s = await chrome.storage.local.get(['isPro', 'licenseKey', 'lastVerifiedAt']);
  if (!s.licenseKey) return false;
  if (!s.lastVerifiedAt || Date.now() - s.lastVerifiedAt > GUN_MS) {
    const r = await dogrulayici.validate(s.licenseKey);
    return !!r.isPro;
  }
  return !!s.isPro;
}

// --- Defter deposu (tek sıralı kuyruk: hızlı art arda kayıtlar birbirini ezmesin) ---
let kuyruk = Promise.resolve();
function sirayla(fn) {
  const p = kuyruk.then(fn, fn);
  kuyruk = p.catch(() => {});
  return p;
}
async function defterleriOku() {
  const { defterler } = await chrome.storage.local.get('defterler');
  return defterler || {};
}
const defterleriYaz = (defterler) => chrome.storage.local.set({ defterler });
const yeniId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

async function kayitEkle(video, kayit, secenek) {
  if (!video || !video.id || !kayit) return { ok: false, hata: 'EKSIK_VERI' };
  const defterler = await defterleriOku();
  const pro = await proMu();
  // Uygulamalı tur defteri örnektir, ücretsiz sınıra sayılmaz — yalnız tur videosu için kabul edilir.
  const ornek = !!(secenek && secenek.ornek) && video.id === globalThis.ZCKurallar.TUR_VIDEO;
  const sayilan = Object.keys(defterler).filter((id) => !defterler[id].ornek);
  const izin = ornek || (defterler[video.id] && defterler[video.id].ornek)
    ? { izin: true }
    : globalThis.ZCKurallar.kayitIzni(sayilan, video.id, pro);
  if (!izin.izin) return { ok: false, hata: 'UCRETSIZ_SINIR', pro };

  // Aynı satır iki kez kaydedilmesin (Alt+T'ye art arda basma): aynı tür + aynı metin, 10 sn içinde.
  const mevcut = defterler[video.id];
  const metinYeni = String(kayit.metin || '').trim();
  if (mevcut && kayit.tur !== 'kare' && metinYeni && mevcut.kayitlar.some((k) =>
    k.tur === kayit.tur && k.metin.trim() === metinYeni && Math.abs(k.t - (Number(kayit.t) || 0)) < 10)) {
    return { ok: true, defter: mevcut, pro, tekrar: true };
  }

  const giris = {
    id: yeniId(),
    t: Math.max(0, Number(kayit.t) || 0),
    tur: ['not', 'kare', 'altyazi'].includes(kayit.tur) ? kayit.tur : 'not',
    metin: String(kayit.metin || '').slice(0, 4000),
    altyazi: String(kayit.altyazi || '').slice(0, 1000),
    olusturma: Date.now()
  };
  if (kayit.kareDataUrl) {
    const blob = await (await fetch(kayit.kareDataUrl)).blob();
    giris.kareId = 'k_' + giris.id;
    await globalThis.ZCDepo.kareYaz(giris.kareId, blob);
  }
  const defter = defterler[video.id] || { videoId: video.id, olusturma: Date.now(), kayitlar: [], ...(ornek ? { ornek: true } : {}) };
  defter.baslik = video.baslik || defter.baslik || video.id;
  defter.kanal = video.kanal || defter.kanal || '';
  defter.guncelleme = Date.now();
  defter.kayitlar.push(giris);
  defterler[video.id] = defter;
  await defterleriYaz(defterler);
  return { ok: true, defter, pro };
}

async function kayitSil(videoId, kayitId) {
  const defterler = await defterleriOku();
  const defter = defterler[videoId];
  if (!defter) return { ok: true, kayitlar: [] };
  const silinen = defter.kayitlar.find((k) => k.id === kayitId);
  defter.kayitlar = defter.kayitlar.filter((k) => k.id !== kayitId);
  if (silinen && silinen.kareId) await globalThis.ZCDepo.kareSil(silinen.kareId).catch((e) => console.warn('[ZenCinema] kare silinemedi', e));
  if (!defter.kayitlar.length) delete defterler[videoId];
  await defterleriYaz(defterler);
  return { ok: true, kayitlar: defter.kayitlar };
}

async function defterSil(videoId) {
  const defterler = await defterleriOku();
  const defter = defterler[videoId];
  if (defter) {
    for (const k of defter.kayitlar) {
      if (k.kareId) await globalThis.ZCDepo.kareSil(k.kareId).catch((e) => console.warn('[ZenCinema] kare silinemedi', e));
    }
    delete defterler[videoId];
    await defterleriYaz(defterler);
  }
  return { ok: true };
}

// --- Mesajlar ---
async function isle(m, gonderen) {
  switch (m.eylem) {
    case 'DEFTER_GETIR': {
      const defterler = await defterleriOku();
      return { ok: true, defter: defterler[m.videoId] || null, pro: await proMu() };
    }
    case 'KAYIT_EKLE':
      return sirayla(() => kayitEkle(m.video, m.kayit, { ornek: m.ornek }));
    case 'KAYIT_SIL':
      return sirayla(() => kayitSil(m.videoId, m.kayitId));
    case 'DEFTER_SIL':
      return sirayla(() => defterSil(m.videoId));
    case 'KARE_GETIR': {
      const blob = await globalThis.ZCDepo.kareOku(m.kareId);
      return blob ? { ok: true, dataUrl: await globalThis.ZCDepo.blobDataUrl(blob) } : { ok: false, hata: 'YOK' };
    }
    case 'DURUM': {
      const s = await chrome.storage.local.get(['licenseKey', 'licenseData', 'licenseError']);
      return { ok: true, pro: await proMu(), anahtarVar: !!s.licenseKey, eposta: (s.licenseData && s.licenseData.customerEmail) || null, hataKodu: s.licenseError || null };
    }
    case 'LISANS_DOGRULA': {
      const r = await dogrulayici.validate(m.anahtar);
      return { ok: !!r.isPro, pro: !!r.isPro, hata: r.error || null };
    }
    case 'DEFTERLERI_AC':
      await chrome.tabs.create({ url: chrome.runtime.getURL('defter/defter.html') });
      return { ok: true };
    case 'SATIN_AL':
      await chrome.tabs.create({ url: SATIN_AL_URL });
      return { ok: true };
    default:
      return { ok: false, hata: 'BILINMEYEN_EYLEM' };
  }
}

chrome.runtime.onMessage.addListener((m, gonderen, cevap) => {
  if (!m || !m.eylem) return false;
  isle(m, gonderen)
    .then(cevap)
    .catch((e) => {
      console.error('[ZenCinema] mesaj hatası', m.eylem, e);
      cevap({ ok: false, hata: String((e && e.message) || e) });
    });
  return true; // asenkron cevap
});

chrome.runtime.onInstalled.addListener((d) => {
  if (d.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('hosgeldin/hosgeldin.html') });
  }
});

// Tarayıcı açılışında lisansı tazele (24 sa'ten eskiyse ağdan doğrular).
chrome.runtime.onStartup.addListener(() => { proMu().catch((e) => console.warn('[ZenCinema] açılış lisans kontrolü', e)); });

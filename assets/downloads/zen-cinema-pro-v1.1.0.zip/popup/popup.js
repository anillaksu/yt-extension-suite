/**
 * Zen Cinema — popup: sinema aç/kapa, otomatik sinema tercihi, defterler, Pro lisans.
 */
document.addEventListener('DOMContentLoaded', async () => {
  const $ = (id) => document.getElementById(id);
  const t = (k, y) => chrome.i18n.getMessage(k) || y || k;
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n, el.textContent); });
  $('surum').textContent = 'v' + chrome.runtime.getManifest().version;

  const mesaj = (eylem, veri) => new Promise((r) => chrome.runtime.sendMessage(Object.assign({ eylem }, veri || {}), (c) => r(c || {})));

  // --- Sinema ---
  const [sekme] = await chrome.tabs.query({ active: true, currentWindow: true });
  async function sinemaDurumu() {
    // Sekme adresi okunmaz (ek izin gerektirir); sayfadaki içerik betiğine sorulur.
    try {
      const c = await chrome.tabs.sendMessage(sekme.id, { eylem: 'SINEMA_DURUM' });
      if (!c || !c.izleSayfasi) {
        $('sinema-dugme').disabled = true;
        $('sinema-ipucu').textContent = t('popSinemaIpucu', 'Open a YouTube video, then press Alt+C.');
        return;
      }
      $('sinema-dugme').textContent = c.acik ? t('popKapat', 'Close') : t('popAc', 'Open');
      $('sinema-ipucu').textContent = t('popSinemaHazir', 'Alt+C toggles it on any video.');
    } catch (e) {
      // YouTube dışı sekme ya da eklenti yeni kuruldu (sayfa yenilenmeli).
      $('sinema-ipucu').textContent = t('popYenile', 'Open a YouTube video (refresh the tab if it was already open).');
      $('sinema-dugme').disabled = true;
    }
  }
  $('sinema-dugme').addEventListener('click', async () => {
    try { await chrome.tabs.sendMessage(sekme.id, { eylem: 'SINEMA_DEGISTIR' }); window.close(); }
    catch (e) { $('sinema-ipucu').textContent = t('popYenile', 'Refresh this YouTube tab once to start.'); }
  });
  const { sinemaOtomatik } = await chrome.storage.local.get('sinemaOtomatik');
  $('otomatik').checked = !!sinemaOtomatik;
  $('otomatik').addEventListener('change', () => chrome.storage.local.set({ sinemaOtomatik: $('otomatik').checked }));
  sinemaDurumu();

  // --- Defterler ---
  $('defterler-dugme').addEventListener('click', () => { mesaj('DEFTERLERI_AC'); window.close(); });

  // --- Lisans ---
  function goster(pro, eposta) {
    $('durum-rozet').textContent = pro ? 'PRO' : t('popUcretsiz', 'Free');
    $('durum-rozet').classList.toggle('pro', pro);
    $('lisans-kart').hidden = pro;
    $('pro-kart').hidden = !pro;
    $('pro-eposta').textContent = eposta || '';
  }
  const durum = await mesaj('DURUM');
  goster(!!durum.pro, durum.eposta);

  function bildir(metin, tur) {
    $('mesaj').textContent = metin;
    $('mesaj').className = 'mesaj ' + (tur || '');
    $('mesaj').hidden = !metin;
  }
  $('dogrula').addEventListener('click', async () => {
    const anahtar = $('lisans').value.trim();
    if (!anahtar) { bildir(t('popAnahtarGir', 'Paste your license key.'), 'kotu'); return; }
    $('dogrula').disabled = true;
    bildir(t('popDogrulaniyor', 'Checking…'));
    const c = await mesaj('LISANS_DOGRULA', { anahtar });
    $('dogrula').disabled = false;
    if (c.pro) {
      bildir(t('popBasarili', 'Pro activated. Thank you!'), 'iyi');
      setTimeout(() => goster(true, null), 700);
    } else {
      bildir(c.hata || t('popGecersiz', 'Invalid license key.'), 'kotu');
    }
  });
  $('lisans').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('dogrula').click(); });
  $('satin-al').addEventListener('click', () => { mesaj('SATIN_AL'); window.close(); });
});

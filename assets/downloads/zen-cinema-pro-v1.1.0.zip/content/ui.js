/**
 * Zen Cinema — arayüz (Shadow DOM; YouTube stilleri karışmaz).
 * Normal modda: sağ altta küçük eylem çubuğu + açılır defter paneli.
 * Sinema modunda: üst bar, ortada alt eylem çubuğu, sağda panel, solda an'a bağlı yorum akışı.
 * Tam ekranda kök oynatıcının içine taşınır; not almak için tam ekrandan çıkmak gerekmez.
 */
(function () {
  'use strict';
  const ZC = globalThis.ZC;
  const S = ZC.saf;
  const t = ZC.t;

  const IKON = {
    not: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
    kare: '<svg viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="13" rx="2"/><circle cx="12" cy="12.5" r="3.2"/><path d="M8 6l1.5-2h5L16 6"/></svg>',
    altyazi: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 11h4M13 11h4M7 15h7"/></svg>',
    defter: '<svg viewBox="0 0 24 24"><path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/></svg>',
    kapat: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    sil: '<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/></svg>',
    sinema: '<svg viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="12" rx="3"/><circle cx="12" cy="12" r="2.2" fill="currentColor" stroke="none"/></svg>',
    disari: '<svg viewBox="0 0 24 24"><path d="M14 4h6v6M10 14L20 4M20 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h5"/></svg>'
  };

  const CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .kok {
    --bg:#14120F; --yuzey:#1D1A16; --yuksek:#26221D; --cizgi:rgba(255,255,255,.08);
    --yazi:#E8E2D6; --sonuk:#A39B8D; --silik:#6b6458; --vurgu:#D9A864; --vurgu-yazi:#14120F;
    --serif: Georgia, "Iowan Old Style", "Times New Roman", serif;
    --ui: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-family: var(--ui); color: var(--yazi); font-size: 13px; line-height: 1.5;
    -webkit-font-smoothing: antialiased;
  }
  .kok[data-gorunur="0"] { display: none; }
  button { font: inherit; color: inherit; background: none; border: 0; cursor: pointer; }
  svg { width: 16px; height: 16px; stroke: currentColor; fill: none; stroke-width: 1.7; stroke-linecap: round; stroke-linejoin: round; flex: none; }
  kbd { font: 600 10px var(--ui); color: var(--silik); border: 1px solid var(--cizgi); border-radius: 5px; padding: 1px 5px; }
  .gecis { transition: opacity .32s cubic-bezier(.2,0,0,1), transform .32s cubic-bezier(.2,0,0,1); }

  /* Üst bar (yalnız sinema) */
  .ust { position: fixed; top: 0; left: 0; right: 0; height: 56px; display: none; align-items: center; justify-content: space-between;
    gap: 16px; padding: 0 24px; pointer-events: auto; }
  .kok[data-mod="sinema"] .ust { display: flex; }
  .marka { display: flex; align-items: center; gap: 10px; }
  .isaret { width: 26px; height: 26px; border-radius: 8px; border: 1px solid var(--cizgi); background: linear-gradient(150deg,#2a241c,#14120f);
    display: flex; align-items: center; justify-content: center; }
  .isaret i { width: 15px; height: 11px; border-radius: 3px; border: 1.6px solid var(--yazi); display: flex; align-items: center; justify-content: center; }
  .isaret i::after { content: ""; width: 4px; height: 4px; border-radius: 50%; background: var(--vurgu); box-shadow: 0 0 6px rgba(217,168,100,.8); }
  .marka b { font: 500 15px var(--serif); letter-spacing: .01em; }
  .baslik { flex: 1; min-width: 0; text-align: center; color: var(--sonuk); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .araclar { display: flex; gap: 6px; }
  .ikon-dugme { width: 34px; height: 34px; border-radius: 10px; border: 1px solid var(--cizgi); background: var(--yuzey);
    display: inline-flex; align-items: center; justify-content: center; color: var(--sonuk); }
  .ikon-dugme:hover { color: var(--yazi); background: var(--yuksek); }

  /* Eylem çubuğu */
  .aksiyon { position: fixed; display: flex; align-items: center; gap: 4px; padding: 6px; border-radius: 14px;
    background: rgba(29,26,22,.94); border: 1px solid var(--cizgi); box-shadow: 0 12px 40px rgba(0,0,0,.35); pointer-events: auto;
    backdrop-filter: blur(8px); }
  .kok[data-mod="normal"] .aksiyon { right: 20px; bottom: 20px; }
  .kok[data-mod="sinema"] .aksiyon { left: 50%; bottom: 24px; transform: translateX(-50%); }
  .eylem { display: inline-flex; align-items: center; gap: 7px; height: 34px; padding: 0 11px; border-radius: 10px; color: var(--sonuk); font-weight: 500; }
  .eylem:hover { color: var(--yazi); background: var(--yuksek); }
  .eylem.birincil { background: var(--vurgu); color: var(--vurgu-yazi); font-weight: 600; }
  .eylem.birincil:hover { background: #e2b676; color: var(--vurgu-yazi); }
  .eylem.birincil kbd { color: rgba(20,18,15,.55); border-color: rgba(20,18,15,.25); }
  .ayrac { width: 1px; height: 20px; background: var(--cizgi); margin: 0 4px; }
  .sayi { font-variant-numeric: tabular-nums; color: var(--vurgu); }
  .kok[data-mod="normal"] .eylem .etiket, .kok[data-mod="normal"] .eylem kbd { display: none; }
  /* Sinema düğmesi: normal modda etiketiyle görünür (keşfedilsin), sinemada üst bardaki kapat yeterli. */
  .eylem.sinema-ac { color: var(--yazi); }
  .eylem.sinema-ac svg circle { fill: var(--vurgu); }
  .kok[data-mod="normal"] .eylem.sinema-ac .etiket { display: inline; }
  .kok[data-mod="sinema"] .sinema-ac, .kok[data-mod="sinema"] .ayrac.sinema-ayrac { display: none; }

  /* Sükunet */
  .kok[data-sukun="1"] .ust, .kok[data-sukun="1"] .aksiyon { opacity: 0; pointer-events: none; }
  .kok[data-sukun="1"] .ust { transform: translateY(-8px); }
  .kok[data-sukun="1"][data-mod="sinema"] .aksiyon { transform: translate(-50%, 8px); }

  /* Not girişi */
  .not-giris { position: fixed; display: flex; align-items: center; gap: 8px; width: min(560px, calc(100vw - 40px)); padding: 8px;
    border-radius: 14px; background: var(--yuzey); border: 1px solid rgba(217,168,100,.35); box-shadow: 0 16px 48px rgba(0,0,0,.45); pointer-events: auto; }
  .kok[data-mod="normal"] .not-giris { right: 20px; bottom: 72px; }
  .kok[data-mod="sinema"] .not-giris { left: 50%; bottom: 76px; transform: translateX(-50%); }
  .rozet { font: 700 12px ui-monospace, Consolas, monospace; color: var(--vurgu-yazi); background: var(--vurgu); padding: 6px 9px; border-radius: 8px; }
  .not-giris input { flex: 1; min-width: 0; height: 34px; padding: 0 12px; border-radius: 9px; border: 1px solid var(--cizgi); background: var(--bg);
    color: var(--yazi); font: 14px var(--ui); outline: none; }
  .not-giris input:focus { border-color: rgba(217,168,100,.5); }

  /* Panel */
  .panel { position: fixed; width: 360px; display: flex; flex-direction: column; border-radius: 16px; background: rgba(29,26,22,.97);
    border: 1px solid var(--cizgi); box-shadow: 0 20px 60px rgba(0,0,0,.5); pointer-events: auto; overflow: hidden; }
  .kok[data-mod="normal"] .panel { top: 72px; right: 20px; bottom: 72px; }
  .kok[data-mod="sinema"] .panel { top: 64px; right: 24px; bottom: 92px; }
  .panel-bas { display: flex; align-items: center; justify-content: space-between; padding: 10px 10px 10px 14px; border-bottom: 1px solid var(--cizgi); }
  .sekmeler { display: flex; gap: 4px; background: var(--bg); padding: 3px; border-radius: 10px; border: 1px solid var(--cizgi); }
  .sekmeler button { padding: 5px 12px; border-radius: 7px; color: var(--sonuk); font-weight: 600; font-size: 12px; }
  .sekmeler button.on { background: var(--yuksek); color: var(--yazi); }
  .liste { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 8px; scrollbar-width: thin; scrollbar-color: #3a342b transparent; }
  .bos { color: var(--silik); text-align: center; padding: 36px 18px; line-height: 1.6; }
  .kayit { display: flex; gap: 10px; padding: 10px; border-radius: 11px; background: rgba(255,255,255,.025); border: 1px solid var(--cizgi); }
  .kayit:hover { border-color: rgba(217,168,100,.28); }
  .zaman { flex: none; align-self: flex-start; font: 700 11px ui-monospace, Consolas, monospace; color: var(--vurgu); background: rgba(217,168,100,.12);
    border: 1px solid rgba(217,168,100,.35); padding: 3px 6px; border-radius: 6px; }
  .zaman:hover { background: var(--vurgu); color: var(--vurgu-yazi); }
  .govde { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; }
  .govde p { color: var(--yazi); word-break: break-word; }
  .govde .tur { font-size: 11px; color: var(--silik); display: flex; align-items: center; gap: 5px; }
  .govde .tur svg { width: 12px; height: 12px; }
  .govde img { width: 100%; border-radius: 8px; border: 1px solid var(--cizgi); display: block; }
  .govde .yazar { font-size: 11px; color: var(--sonuk); font-weight: 600; }
  .sil { flex: none; align-self: flex-start; color: var(--silik); opacity: .6; }
  .sil:hover { color: #e07a6a; opacity: 1; }
  .panel-alt { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 14px; border-top: 1px solid var(--cizgi); }
  .baglanti { display: inline-flex; align-items: center; gap: 6px; color: var(--sonuk); font-weight: 600; font-size: 12px; }
  .baglanti:hover { color: var(--yazi); }
  .pro-durum { font-size: 11px; color: var(--silik); }
  .pro-durum.pro { color: var(--vurgu); font-weight: 700; }
  .dugme-ikincil { height: 30px; padding: 0 12px; border-radius: 9px; border: 1px solid var(--cizgi); color: var(--sonuk); font-weight: 600; font-size: 12px; }
  .dugme-ikincil:hover { color: var(--yazi); background: var(--yuksek); }

  /* An'a bağlı yorum akışı */
  .akis { position: fixed; display: flex; flex-direction: column; gap: 8px; width: 320px; pointer-events: auto; }
  /* Sol alt köşe YouTube'un kendi tanıtım/bildirim kutularına ait (ölçüldü: "YouTube Premium" kutusu); oraya konmaz. */
  .kok[data-mod="sinema"] .akis { left: 40px; top: 80px; }
  .kok[data-mod="normal"] .akis { right: 20px; bottom: 84px; }
  .an { display: flex; gap: 9px; padding: 10px 12px; border-radius: 12px; background: rgba(20,18,15,.94); border: 1px solid var(--cizgi);
    box-shadow: 0 10px 30px rgba(0,0,0,.35); animation: belir .35s cubic-bezier(.2,0,0,1); }
  .an p { color: var(--yazi); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
  @keyframes belir { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }

  /* Bildirim ve teklif */
  .bildirim { position: fixed; left: 50%; top: 72px; transform: translateX(-50%); padding: 9px 14px; border-radius: 11px; background: var(--yuksek);
    border: 1px solid var(--cizgi); color: var(--yazi); box-shadow: 0 12px 36px rgba(0,0,0,.4); pointer-events: none; max-width: 80vw; }
  .teklif-arka { position: fixed; inset: 0; background: rgba(0,0,0,.6); display: flex; align-items: center; justify-content: center; pointer-events: auto; }
  .teklif { width: min(420px, calc(100vw - 32px)); padding: 24px; border-radius: 18px; background: var(--yuzey); border: 1px solid var(--cizgi);
    box-shadow: 0 30px 80px rgba(0,0,0,.6); }
  .teklif h3 { font: 500 20px var(--serif); margin-bottom: 8px; }
  .teklif p { color: var(--sonuk); margin-bottom: 10px; line-height: 1.6; }
  .teklif ul { list-style: none; margin: 4px 0 18px; display: grid; gap: 6px; }
  .teklif li { display: flex; gap: 8px; color: var(--yazi); }
  .teklif li::before { content: ""; width: 6px; height: 6px; margin-top: 8px; border-radius: 50%; background: var(--vurgu); flex: none; }
  .teklif .eylemler { display: flex; gap: 8px; justify-content: flex-end; }
  .teklif .eylem.birincil { height: 38px; padding: 0 16px; }
  /* Uygulamalı tur: rehber kartı + hedef düğmede nabız halkası */
  .rehber { position: fixed; width: min(360px, calc(100vw - 32px)); padding: 18px 18px 14px; border-radius: 18px; pointer-events: auto;
    background: linear-gradient(180deg, rgba(42,37,31,.97), rgba(29,26,22,.97)); border: 1px solid rgba(217,168,100,.38);
    box-shadow: 0 30px 80px rgba(0,0,0,.55), 0 0 0 1px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.05);
    animation: tur-gir .45s cubic-bezier(.2,0,0,1); }
  .kok[data-mod="normal"] .rehber { right: 20px; bottom: 76px; }
  .kok[data-mod="sinema"] .rehber { left: 50%; top: 72px; transform: translateX(-50%); }
  @keyframes tur-gir { from { opacity: 0; translate: 0 10px; scale: .97; } to { opacity: 1; translate: 0 0; scale: 1; } }
  .tur-noktalar { display: flex; gap: 5px; margin-bottom: 12px; }
  .tur-noktalar i { height: 4px; flex: 1; border-radius: 4px; background: rgba(255,255,255,.1); transition: background .4s; }
  .tur-noktalar i.tamam { background: var(--vurgu); }
  .tur-noktalar i.simdi { background: linear-gradient(90deg, var(--vurgu), rgba(217,168,100,.25)); }
  .rehber h4 { font: 500 19px/1.3 var(--serif); color: var(--yazi); margin-bottom: 6px; }
  .rehber p { color: var(--sonuk); font-size: 13.5px; line-height: 1.6; }
  .rehber p b { color: var(--yazi); }
  .tur-alt { display: flex; align-items: center; justify-content: space-between; margin-top: 14px; gap: 8px; }
  .tur-sayac { font-size: 11px; color: var(--silik); font-weight: 600; letter-spacing: .06em; }
  .tur-alt .eylemler { display: flex; gap: 6px; }
  .rehber .eylem.birincil { height: 32px; }
  .rehber.basari { border-color: rgba(143,181,166,.6); }
  .rehber.basari h4::before { content: "✓ "; color: #8FB5A6; }
  [data-tur-hedef] { position: relative; box-shadow: 0 0 0 2px var(--vurgu); animation: tur-nabiz 1.6s ease-out infinite; }
  @keyframes tur-nabiz { 0% { box-shadow: 0 0 0 2px var(--vurgu), 0 0 0 0 rgba(217,168,100,.55); }
    100% { box-shadow: 0 0 0 2px var(--vurgu), 0 0 0 14px rgba(217,168,100,0); } }
  /* Tur sürerken arayüz susmaz; bildirimler kartla çakışmasın diye alta iner. */
  .kok[data-tur="1"] .ust, .kok[data-tur="1"] .aksiyon { opacity: 1 !important; pointer-events: auto !important; }
  .kok[data-tur="1"][data-mod="sinema"] .aksiyon { transform: translateX(-50%) !important; }
  .kok[data-tur="1"] .bildirim { top: auto; bottom: 140px; }
  .kok[data-tur="1"][data-mod="normal"] .akis { display: none; }
  [hidden] { display: none !important; }
  `;

  let host, kok, $ = (s) => kok.querySelector(s);
  let panelAcik = false;
  let sekme = 'defter';
  let bildirimZaman = null;
  const kareOnbellek = new Map();

  function olustur() {
    host = document.createElement('div');
    host.id = 'zc-kok';
    host.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483000;';
    const golge = host.attachShadow({ mode: 'open' });
    golge.innerHTML = `<style>${CSS}</style>
    <div class="kok" data-mod="normal" data-sukun="0" data-gorunur="0">
      <header class="ust gecis">
        <div class="marka"><span class="isaret"><i></i></span><b>Zen Cinema</b></div>
        <div class="baslik"></div>
        <div class="araclar">
          <button class="ikon-dugme" data-is="panel" title="${t('zcDefter', 'Defter')}">${IKON.defter}</button>
          <button class="ikon-dugme" data-is="kapat" title="${t('zcSinemadanCik', 'Sinemadan çık')} (Alt+C)">${IKON.kapat}</button>
        </div>
      </header>
      <div class="akis"></div>
      <div class="aksiyon gecis">
        <button class="eylem sinema-ac" data-is="sinema" title="${t('zcSinemaAc', 'Sinema moduna al')} (Alt+C)">${IKON.sinema}<span class="etiket">${t('zcSinema', 'Sinema')}</span></button>
        <span class="ayrac sinema-ayrac"></span>
        <button class="eylem birincil" data-is="not" title="${t('zcNotAl', 'Not al')} (Alt+N)">${IKON.not}<span class="etiket">${t('zcNot', 'Not')}</span><kbd>Alt N</kbd></button>
        <button class="eylem" data-is="kare" title="${t('zcKareAl', 'Kare görüntüsü al')} (Alt+S)">${IKON.kare}<span class="etiket">${t('zcKare', 'Kare')}</span><kbd>Alt S</kbd></button>
        <button class="eylem" data-is="altyazi" title="${t('zcAltyaziAl', 'Bu anın altyazısını kaydet')} (Alt+T)">${IKON.altyazi}<span class="etiket">${t('zcAltyazi', 'Altyazı')}</span><kbd>Alt T</kbd></button>
        <span class="ayrac"></span>
        <button class="eylem" data-is="panel" title="${t('zcDefter', 'Defter')}">${IKON.defter}<span class="etiket">${t('zcDefter', 'Defter')}</span><span class="sayi"></span></button>
      </div>
      <div class="not-giris" hidden>
        <span class="rozet">00:00</span>
        <input type="text" maxlength="2000" placeholder="${t('zcNotYer', 'Bu ana notunu yaz, Enter ile kaydet')}">
        <button class="eylem birincil" data-is="not-kaydet">${t('zcKaydet', 'Kaydet')}</button>
      </div>
      <aside class="panel" hidden>
        <div class="panel-bas">
          <div class="sekmeler">
            <button data-sekme="defter" class="on">${t('zcDefter', 'Defter')}</button>
            <button data-sekme="anlar">${t('zcAnlar', 'Anlar')} <span class="sayi anlar-sayi"></span></button>
          </div>
          <button class="ikon-dugme" data-is="panel-kapat">${IKON.kapat}</button>
        </div>
        <div class="liste" data-icerik="defter"></div>
        <div class="liste" data-icerik="anlar" hidden></div>
        <div class="panel-alt">
          <button class="baglanti" data-is="defterler">${t('zcTumDefterler', 'Tüm defterler')} ${IKON.disari}</button>
          <span class="pro-durum"></span>
        </div>
      </aside>
      <div class="bildirim" hidden></div>
      <div class="rehber" hidden role="dialog" aria-live="polite">
        <div class="tur-noktalar"></div>
        <h4></h4>
        <p></p>
        <div class="tur-alt">
          <span class="tur-sayac"></span>
          <div class="eylemler">
            <button class="dugme-ikincil" data-is="tur-kapat">${t('turKapat', 'Turu kapat')}</button>
            <button class="dugme-ikincil" data-is="tur-atla">${t('turAtla', 'Atla')}</button>
            <button class="eylem birincil" data-is="tur-bitir" hidden>${t('turTumDefterler', 'Tüm defterler')}</button>
          </div>
        </div>
      </div>
      <div class="teklif-arka" hidden>
        <div class="teklif">
          <h3>${t('zcTeklifBaslik', 'Defterin dolmaya başladı')}</h3>
          <p class="teklif-metin">${t('zcTeklifMetin', 'Ücretsiz sürümde 3 videoya kadar defter tutabilirsin.')}</p>
          <ul>
            <li>${t('zcTeklif1', 'Sınırsız video defteri')}</li>
            <li>${t('zcTeklif2', 'Markdown + görseller (ZIP) ve PDF dışa aktarma')}</li>
            <li>${t('zcTeklif3', 'Tek seferlik ödeme, ömür boyu')}</li>
          </ul>
          <div class="eylemler">
            <button class="dugme-ikincil" data-is="teklif-kapat">${t('zcSimdiDegil', 'Şimdi değil')}</button>
            <button class="eylem birincil" data-is="teklif-al">${t('zcProyaGec', "Pro'ya geç · $19.99")}</button>
          </div>
        </div>
      </div>
    </div>`;
    kok = golge.querySelector('.kok');
    document.documentElement.appendChild(host);
    baglan(golge);
  }

  function baglan(golge) {
    golge.addEventListener('click', (e) => {
      const d = e.target.closest('[data-is],[data-sekme]');
      if (!d) return;
      const is = d.getAttribute('data-is');
      if (d.hasAttribute('data-sekme')) { sekmeSec(d.getAttribute('data-sekme')); return; }
      if (is === 'panel') panelDegistir();
      else if (is === 'panel-kapat') panelKapat();
      else if (is === 'kapat') ZC.sinema && ZC.sinema.kapat();
      else if (is === 'sinema') ZC.sinema && ZC.sinema.ac();
      else if (is === 'defterler') ZC.mesaj('DEFTERLERI_AC');
      else if (is === 'teklif-kapat') $('.teklif-arka').hidden = true;
      else if (is === 'teklif-al') { ZC.mesaj('SATIN_AL'); $('.teklif-arka').hidden = true; }
      else if (is === 'not-kaydet') notGirisiBitir(true);
      else if (is === 'tur-kapat') ZC.yay('tur', 'kapat');
      else if (is === 'tur-atla') ZC.yay('tur', 'atla');
      else if (is === 'tur-bitir') ZC.yay('tur', 'defterler');
      else ZC.yay('eylem', is);
    });
    const giris = $('.not-giris input');
    giris.addEventListener('keydown', (e) => {
      e.stopPropagation(); // YouTube kısayolları yazarken tetiklenmesin
      if (e.key === 'Enter') notGirisiBitir(true);
      if (e.key === 'Escape') notGirisiBitir(false);
    });
    giris.addEventListener('keyup', (e) => e.stopPropagation());
    giris.addEventListener('keypress', (e) => e.stopPropagation());
  }

  // --- Not girişi ---
  let girisCoz = null;
  function notGirisi(saniye) {
    if (girisCoz) notGirisiBitir(false);
    $('.rozet').textContent = S.zamanBicim(saniye);
    const kutu = $('.not-giris');
    kutu.hidden = false;
    document.documentElement.classList.add('zc-not-acik'); // altyazı not alanının üstüne kalksın (sinema.css)
    const giris = kutu.querySelector('input');
    giris.value = '';
    setTimeout(() => giris.focus(), 0);
    return new Promise((r) => { girisCoz = r; });
  }
  function notGirisiBitir(kaydet) {
    const kutu = $('.not-giris');
    const metin = kutu.querySelector('input').value.trim();
    kutu.hidden = true;
    document.documentElement.classList.remove('zc-not-acik');
    const r = girisCoz; girisCoz = null;
    if (r) r(kaydet && metin ? metin : null);
  }

  // --- Panel ---
  function panelAc(hangi) {
    panelAcik = true;
    $('.panel').hidden = false;
    if (hangi) sekmeSec(hangi);
    if (ZC.sinema && ZC.sinema.acikMi()) ZC.sinema.sahneGenisliginiAyarla(384);
    ZC.yay('panel', true);
  }
  function panelKapat() {
    panelAcik = false;
    $('.panel').hidden = true;
    if (ZC.sinema) ZC.sinema.sahneGenisliginiAyarla(0);
  }
  function panelDegistir() { panelAcik ? panelKapat() : panelAc(); }
  function sekmeSec(ad) {
    sekme = ad;
    kok.querySelectorAll('.sekmeler button').forEach((b) => b.classList.toggle('on', b.getAttribute('data-sekme') === ad));
    kok.querySelectorAll('.liste').forEach((l) => { l.hidden = l.getAttribute('data-icerik') !== ad; });
    if (ad === 'anlar') ZC.yay('anlarIstendi');
  }

  function el(etiket, sinif, metin) {
    const e = document.createElement(etiket);
    if (sinif) e.className = sinif;
    if (metin !== undefined) e.textContent = metin;
    return e;
  }

  function zamanDugmesi(saniye) {
    const b = el('button', 'zaman', S.zamanBicim(saniye));
    b.title = t('zcBuAnaGit', 'Bu ana git');
    b.addEventListener('click', () => ZC.videyaGit(saniye));
    return b;
  }

  async function kareGetir(kareId, img) {
    if (kareOnbellek.has(kareId)) { img.src = kareOnbellek.get(kareId); return; }
    const c = await ZC.mesaj('KARE_GETIR', { kareId });
    if (c && c.ok && c.dataUrl) { kareOnbellek.set(kareId, c.dataUrl); img.src = c.dataUrl; }
  }

  function defterCiz(kayitlar) {
    const liste = $('[data-icerik="defter"]');
    liste.textContent = '';
    const sayi = (kayitlar || []).length;
    kok.querySelectorAll('.aksiyon .sayi').forEach((s) => { s.textContent = sayi ? String(sayi) : ''; });
    if (!sayi) {
      liste.appendChild(el('div', 'bos', t('zcDefterBos', 'Bu videoda henüz kayıt yok. Alt+N not, Alt+S kare, Alt+T altyazı kaydeder.')));
      return;
    }
    kayitlar.slice().sort((a, b) => a.t - b.t).forEach((k) => {
      const satir = el('div', 'kayit');
      satir.appendChild(zamanDugmesi(k.t));
      const govde = el('div', 'govde');
      const tur = el('span', 'tur');
      tur.innerHTML = IKON[k.tur === 'kare' ? 'kare' : k.tur === 'altyazi' ? 'altyazi' : 'not'];
      tur.appendChild(document.createTextNode(k.tur === 'kare' ? t('zcKare', 'Kare') : k.tur === 'altyazi' ? t('zcAltyazi', 'Altyazı') : t('zcNot', 'Not')));
      govde.appendChild(tur);
      if (k.metin) govde.appendChild(el('p', '', k.metin));
      if (k.kareId) {
        const img = el('img');
        img.alt = '';
        govde.appendChild(img);
        kareGetir(k.kareId, img);
      }
      satir.appendChild(govde);
      const sil = el('button', 'sil');
      sil.innerHTML = IKON.sil;
      sil.title = t('zcSil', 'Sil');
      sil.addEventListener('click', () => ZC.yay('sil', k.id));
      satir.appendChild(sil);
      liste.appendChild(satir);
    });
  }

  function yorumKarti(y, sinif) {
    const kart = el('div', sinif);
    kart.appendChild(zamanDugmesi(y.t));
    const govde = el('div', 'govde');
    if (y.yazar) govde.appendChild(el('span', 'yazar', y.yazar));
    govde.appendChild(el('p', '', y.metin));
    kart.appendChild(govde);
    return kart;
  }

  let sonYorumlar = [];
  let yorumYukleniyor = false;
  function anlarCiz(yorumlar) {
    if (!kok) return;
    sonYorumlar = yorumlar || [];
    const liste = $('[data-icerik="anlar"]');
    liste.textContent = '';
    $('.anlar-sayi').textContent = sonYorumlar.length ? String(sonYorumlar.length) : '';
    if (!sonYorumlar.length) {
      liste.appendChild(el('div', 'bos', yorumYukleniyor
        ? t('zcAnlarYukleniyor', 'Yorumlar yükleniyor…')
        : t('zcAnlarBos', 'Bu videoda zaman damgası geçen yorum bulunamadı (henüz yüklenenler arasında).')));
      return;
    }
    yorumlar.forEach((y) => liste.appendChild(yorumKarti(y, 'kayit')));
  }

  let akisAnahtar = '';
  function akisGoster(yorumlar) {
    const akis = $('.akis');
    const secilen = (yorumlar || []).slice(0, 2);
    const anahtar = secilen.map((y) => y.t + y.metin.slice(0, 20)).join('|');
    if (anahtar === akisAnahtar) return;
    akisAnahtar = anahtar;
    akis.textContent = '';
    secilen.forEach((y) => akis.appendChild(yorumKarti(y, 'an')));
  }

  function bildir(metin, sure) {
    const b = $('.bildirim');
    b.textContent = metin;
    b.hidden = false;
    clearTimeout(bildirimZaman);
    bildirimZaman = setTimeout(() => { b.hidden = true; }, sure || 2400);
  }

  function proTeklifi(metin) {
    if (metin) $('.teklif-metin').textContent = metin;
    $('.teklif-arka').hidden = false;
  }

  function proDurum(pro) {
    const d = $('.pro-durum');
    d.textContent = pro ? 'PRO' : t('zcUcretsiz', 'Ücretsiz · 3 video');
    d.classList.toggle('pro', !!pro);
  }

  function modGuncelle() {
    if (!kok) return;
    const izle = ZC.izleSayfasi();
    kok.setAttribute('data-gorunur', izle ? '1' : '0');
    kok.setAttribute('data-mod', ZC.sinema && ZC.sinema.acikMi() ? 'sinema' : 'normal');
    if (!izle) { panelKapat(); $('.akis').textContent = ''; }
  }

  // Tam ekranda kökü oynatıcının içine taşı (yoksa tam ekranda görünmez).
  document.addEventListener('fullscreenchange', () => {
    if (!host) return;
    const hedef = document.fullscreenElement || document.documentElement;
    if (host.parentNode !== hedef) hedef.appendChild(host);
  });

  ZC.on('sinema', () => {
    modGuncelle();
    if (ZC.sinema.acikMi() && panelAcik) ZC.sinema.sahneGenisliginiAyarla(384);
  });
  ZC.on('sukun', (s) => { if (kok) kok.setAttribute('data-sukun', s ? '1' : '0'); });
  ZC.on('bildirim', (m) => bildir(m));
  ZC.on('yorumlar', (liste) => anlarCiz(liste));

  function baslat() {
    if (!host) olustur();
    modGuncelle();
  }
  document.addEventListener('yt-navigate-finish', baslat);
  if (document.readyState !== 'loading') baslat();
  else document.addEventListener('DOMContentLoaded', baslat);

  ZC.on('yorumYukleniyor', (v) => { yorumYukleniyor = !!v; anlarCiz(sonYorumlar); });

  // --- Uygulamalı tur kartı ---
  function turHedefTemizle() { kok.querySelectorAll('[data-tur-hedef]').forEach((e) => e.removeAttribute('data-tur-hedef')); }
  function turGoster({ adim, toplam, baslik, metin, hedef, son, basari }) {
    if (!kok) return;
    kok.setAttribute('data-gorunur', '1');
    kok.setAttribute('data-tur', '1');
    const kart = $('.rehber');
    kart.hidden = false;
    kart.classList.toggle('basari', !!basari);
    // Kart her adımda yeniden belirsin (göz yeni adımı fark etsin).
    kart.style.animation = 'none'; void kart.offsetWidth; kart.style.animation = '';
    const noktalar = $('.tur-noktalar');
    noktalar.textContent = '';
    for (let i = 1; i <= toplam; i++) {
      const n = document.createElement('i');
      if (i < adim || son) n.className = 'tamam'; else if (i === adim) n.className = 'simdi';
      noktalar.appendChild(n);
    }
    kart.querySelector('h4').textContent = baslik;
    kart.querySelector('p').textContent = metin;
    $('.tur-sayac').textContent = son ? '' : `${adim} / ${toplam}`;
    kart.querySelector('[data-is="tur-atla"]').hidden = !!son;
    kart.querySelector('[data-is="tur-bitir"]').hidden = !son;
    kart.querySelector('[data-is="tur-kapat"]').textContent = son ? t('turBitir', 'Bitir') : t('turKapat', 'Turu kapat');
    turHedefTemizle();
    if (hedef) { const h = kok.querySelector(hedef); if (h) h.setAttribute('data-tur-hedef', ''); }
  }
  function turGizle() {
    if (!kok) return;
    $('.rehber').hidden = true;
    kok.removeAttribute('data-tur');
    turHedefTemizle();
  }

  ZC.ui = { notGirisi, panelAc, panelKapat, defterCiz, anlarCiz, akisGoster, bildir, proTeklifi, proDurum, modGuncelle, turGoster, turGizle,
    hazir: () => !!kok,
    baslikYaz: (m) => { if (kok) $('.baslik').textContent = m || ''; } };
})();

/**
 * Zen Cinema — video defteri: not, kare görüntüsü, altyazı satırı.
 * Kayıtlar arka plana gönderilir (metadata chrome.storage, kareler IndexedDB).
 * Ücretsiz sınır arka planda uygulanır; dolunca Pro teklifi gösterilir.
 */
(function () {
  'use strict';
  const ZC = globalThis.ZC;
  const S = ZC.saf;
  const t = ZC.t;
  let kayitlar = [];
  let videoBilgi = null;

  async function bilgiTazele() {
    // Başlık öğesi sayfa yüklenirken boş ya da genel ("YouTube") olabilir; gerçek başlığı bekle (en çok ~6 sn).
    for (let i = 0; i < 20; i++) {
      videoBilgi = ZC.videoBilgisi();
      if (videoBilgi.baslik && videoBilgi.baslik !== 'YouTube') break;
      await ZC.bekle(300);
    }
    if (ZC.ui) ZC.ui.baslikYaz(videoBilgi.baslik);
    return videoBilgi;
  }

  async function defteriYukle() {
    const id = ZC.videoId();
    if (!id) return;
    const c = await ZC.mesaj('DEFTER_GETIR', { videoId: id });
    kayitlar = (c && c.ok && c.defter && c.defter.kayitlar) || [];
    if (ZC.ui) { ZC.ui.defterCiz(kayitlar); ZC.ui.proDurum(c && c.pro); }
  }

  async function kaydet(kayit) {
    const gecerli = videoBilgi && videoBilgi.id === ZC.videoId() && videoBilgi.baslik && videoBilgi.baslik !== 'YouTube';
    const bilgi = gecerli ? videoBilgi : await bilgiTazele();
    // Uygulamalı turda tutulan defter örnektir; ücretsiz 3 video hakkından düşmez (arka plan video kimliğini ayrıca denetler).
    const ornek = !!(ZC.tur && ZC.tur.aktif());
    const c = await ZC.mesaj('KAYIT_EKLE', { video: bilgi, kayit, ornek });
    if (c && c.ok) {
      kayitlar = c.defter.kayitlar;
      ZC.ui.defterCiz(kayitlar);
      ZC.yay('kaydedildi', kayit.tur);
      return true;
    }
    if (c && c.hata === 'UCRETSIZ_SINIR') {
      ZC.ui.proTeklifi(t('zcTeklifMetin', 'Ücretsiz sürümde 3 videoya kadar defter tutabilirsin.'));
      return false;
    }
    ZC.ui.bildir(t('zcKayitHata', 'Kaydedilemedi') + (c && c.hata ? ': ' + c.hata : ''));
    return false;
  }

  // Kare: video karesi canvas'a çizilir. DRM'li içerikte kare siyah gelir → uyarı, kare kaydedilmez.
  function kareYakala(v) {
    if (!v || v.readyState < 2 || !v.videoWidth) return { hata: 'HAZIR_DEGIL' };
    const olcek = Math.min(1, 1280 / v.videoWidth);
    const c = document.createElement('canvas');
    c.width = Math.round(v.videoWidth * olcek);
    c.height = Math.round(v.videoHeight * olcek);
    const ctx = c.getContext('2d', { willReadFrequently: true });
    try {
      ctx.drawImage(v, 0, 0, c.width, c.height);
    } catch (e) {
      return { hata: 'CIZILEMEDI' };
    }
    // 5x5 ızgara örnekle; neredeyse tamamı siyahsa korumalı içerik say.
    let karanlik = 0, toplam = 0;
    for (let i = 1; i <= 5; i++) {
      for (let j = 1; j <= 5; j++) {
        const p = ctx.getImageData(Math.floor(c.width * i / 6), Math.floor(c.height * j / 6), 1, 1).data;
        toplam++;
        if (p[0] + p[1] + p[2] < 12) karanlik++;
      }
    }
    if (karanlik === toplam) return { hata: 'SIYAH' };
    return { dataUrl: c.toDataURL('image/jpeg', 0.82) };
  }

  async function eylem(ad) {
    if (!ZC.izleSayfasi()) return;
    if (ZC.reklamVar()) {
      ZC.ui.bildir(t('zcReklamSirasinda', 'Reklam oynarken kayıt alınmaz; video dönünce tekrar dene.'), 3200);
      return;
    }
    const v = ZC.video();
    const an = v ? v.currentTime : 0;

    if (ad === 'not') {
      const oynuyordu = v && !v.paused;
      if (oynuyordu) ZC.oynatici('durdur');
      const altyazi = ZC.altyazi.ekrandaki(); // not açıldığı andaki görünen satır; bekletmez
      const metin = await ZC.ui.notGirisi(an);
      if (metin) {
        if (await kaydet({ t: an, tur: 'not', metin, altyazi })) ZC.ui.bildir(t('zcNotKaydedildi', 'Not kaydedildi'));
      }
      if (oynuyordu) ZC.oynatici('oynat');
      return;
    }

    if (ad === 'kare') {
      const sonuc = kareYakala(v);
      if (sonuc.hata === 'SIYAH') {
        ZC.ui.bildir(t('zcDrmUyari', 'Bu içerik korumalı (DRM); kare alınamıyor. Not ve altyazı yine kaydedilebilir.'), 4200);
        return;
      }
      if (sonuc.hata) { ZC.ui.bildir(t('zcKareHazirDegil', 'Video henüz hazır değil, bir saniye sonra tekrar dene.')); return; }
      if (await kaydet({ t: an, tur: 'kare', metin: ZC.altyazi.ekrandaki(), kareDataUrl: sonuc.dataUrl })) {
        ZC.ui.bildir(t('zcKareKaydedildi', 'Kare kaydedildi'));
      }
      return;
    }

    if (ad === 'altyazi') {
      const s = await ZC.altyazi.satirAl(3000);
      if (s.metin) {
        if (await kaydet({ t: an, tur: 'altyazi', metin: s.metin })) ZC.ui.bildir(t('zcAltyaziKaydedildi', 'Altyazı satırı kaydedildi'));
      } else if (s.ccYok) {
        ZC.ui.bildir(t('zcAltyaziYok', 'Bu videoda altyazı yok.'), 3200);
      } else {
        // CC açıldı ama şu an konuşma yok: kullanıcı konuşma anında tekrar basar.
        ZC.ui.bildir(t('zcAltyaziBekle', 'Altyazı açık; konuşma ekranda görününce Alt+T ile kaydet.'), 3600);
      }
    }
  }

  ZC.on('eylem', eylem);
  ZC.on('sil', async (kayitId) => {
    const c = await ZC.mesaj('KAYIT_SIL', { videoId: ZC.videoId(), kayitId });
    if (c && c.ok) { kayitlar = c.kayitlar; ZC.ui.defterCiz(kayitlar); }
  });

  // Kısayollar: Alt+N / Alt+S / Alt+T (YouTube'un tek harf kısayollarıyla çakışmaz; Mac'te e.code ile).
  window.addEventListener('keydown', (e) => {
    if (!ZC.izleSayfasi() || !e.altKey || e.ctrlKey || e.metaKey || ZC.yaziyorMu(e)) return;
    const ad = { KeyN: 'not', KeyS: 'kare', KeyT: 'altyazi' }[e.code];
    if (!ad) return;
    e.preventDefault();
    e.stopPropagation();
    eylem(ad);
  }, true);

  // An'a bağlı yorum akışı: oynatma ilerledikçe ±5 sn içindeki yorumlar.
  let sonSaniye = -1;
  function anTakip() {
    const v = ZC.video();
    if (!v || !ZC.yorumlar || !ZC.ui) return;
    if (ZC.reklamVar()) { if (sonSaniye !== -2) { sonSaniye = -2; ZC.ui.akisGoster([]); } return; }
    const sn = Math.floor(v.currentTime);
    if (sn === sonSaniye) return;
    sonSaniye = sn;
    ZC.ui.akisGoster(ZC.yorumlar.andakiler(v.currentTime, 5));
  }
  setInterval(anTakip, 500);

  async function sayfaDegisti() {
    kayitlar = [];
    if (!ZC.izleSayfasi()) return;
    await ZC.ogeBekle('#movie_player video', 8000);
    await bilgiTazele();
    await defteriYukle();
  }
  document.addEventListener('yt-navigate-finish', sayfaDegisti);
  if (document.readyState !== 'loading') sayfaDegisti();
  else document.addEventListener('DOMContentLoaded', sayfaDegisti);

  // Lisans popup'tan değişince Pro durumunu tazele.
  chrome.storage.onChanged.addListener((d, alan) => { if (alan === 'local' && d.isPro) defteriYukle(); });
})();

/**
 * Zen Cinema — an'a bağlı yorumlar.
 * Sayfada yüklenmiş yorumlardan zaman damgası (3:42, 1:02:03 veya &t= bağlantısı) geçenleri toplar.
 * Sinema modunda sayfa görünmez olduğundan birkaç yorum partisini kullanıcıya hissettirmeden yükler.
 * Yalnız OKUR; yorum göndermez.
 */
(function () {
  'use strict';
  const ZC = globalThis.ZC;
  const S = ZC.saf;
  let liste = [];
  let anahtarlar = new Set();
  let aktifVideo = null;
  let gozcu = null;
  let yukleniyor = false;

  function sifirla() {
    liste = [];
    anahtarlar = new Set();
    aktifVideo = ZC.videoId();
    ZC.yay('yorumlar', liste);
  }

  function tara() {
    if (ZC.videoId() !== aktifVideo) sifirla();
    const v = ZC.video();
    const sure = v && isFinite(v.duration) ? v.duration : undefined;
    let yeni = 0;
    document.querySelectorAll('ytd-comments ytd-comment-thread-renderer').forEach((thread) => {
      const icerik = thread.querySelector('#content-text');
      if (!icerik) return;
      const metin = (icerik.innerText || icerik.textContent || '').trim();
      if (!metin) return;
      const yazar = ((thread.querySelector('#author-text') || {}).textContent || '').trim();
      const zamanlar = new Set(S.metindekiZamanlar(metin, sure));
      icerik.querySelectorAll('a[href*="t="]').forEach((a) => {
        const t = S.hreftenZaman(a.getAttribute('href'));
        if (t !== null && (!sure || t <= sure)) zamanlar.add(t);
      });
      zamanlar.forEach((t) => {
        const anahtar = yazar + '|' + t + '|' + metin.slice(0, 80);
        if (anahtarlar.has(anahtar)) return;
        anahtarlar.add(anahtar);
        liste.push({ t, yazar, metin: metin.length > 280 ? metin.slice(0, 277) + '…' : metin });
        yeni++;
      });
    });
    if (yeni) {
      liste.sort((a, b) => a.t - b.t);
      ZC.yay('yorumlar', liste);
    }
    return yeni;
  }

  function gozle() {
    if (gozcu) gozcu.disconnect();
    const kap = document.querySelector('ytd-comments#comments');
    if (!kap) return;
    let zaman = null;
    gozcu = new MutationObserver(() => {
      clearTimeout(zaman);
      zaman = setTimeout(tara, 300);
    });
    gozcu.observe(kap, { childList: true, subtree: true });
  }

  const threadSayisi = () => document.querySelectorAll('ytd-comments ytd-comment-thread-renderer').length;

  // Sinema açıkken: görünmez sayfayı yorumların sonuna kaydır → YouTube sonraki partiyi yükler → geri dön.
  async function partileriYukle(parti) {
    if (yukleniyor || !ZC.sinema || !ZC.sinema.acikMi()) return;
    const kap = await ZC.ogeBekle('ytd-comments#comments', 4000);
    if (!kap) return;
    yukleniyor = true;
    ZC.yay('yorumYukleniyor', true);
    const eskiY = window.scrollY;
    try {
      for (let i = 0; i < (parti || 5); i++) {
        if (!ZC.sinema.acikMi()) break;
        const once = threadSayisi();
        const alt = kap.getBoundingClientRect().bottom + window.scrollY;
        window.scrollTo(0, Math.max(0, alt - window.innerHeight + 50));
        // YouTube'un sonraki partiyi getirmesi ağa göre 1-6 sn sürebiliyor (ölçüldü: 3 sn bazen yetmedi).
        let bekle = 0;
        while (threadSayisi() === once && bekle < 6000) { await ZC.bekle(250); bekle += 250; }
        if (threadSayisi() === once) break; // daha fazla yorum yok ya da yorumlar kapalı
      }
    } finally {
      window.scrollTo(0, eskiY);
      yukleniyor = false;
      tara();
      ZC.yay('yorumYukleniyor', false);
    }
  }

  async function sayfaDegisti() {
    sifirla();
    if (!ZC.izleSayfasi()) return;
    await ZC.ogeBekle('ytd-comments#comments', 8000);
    gozle();
    tara();
    if (ZC.sinema && ZC.sinema.acikMi()) setTimeout(() => partileriYukle(5), 1500);
  }

  document.addEventListener('yt-navigate-finish', sayfaDegisti);
  if (document.readyState !== 'loading') sayfaDegisti();
  else document.addEventListener('DOMContentLoaded', sayfaDegisti);
  ZC.on('sinema', (acik) => { if (acik) setTimeout(() => partileriYukle(5), 800); });
  // "Anlar" sekmesi açıldığında yeterli yorum yoksa bir parti daha dene.
  ZC.on('anlarIstendi', () => { if (liste.length < 3) partileriYukle(3); });

  ZC.yorumlar = {
    liste: () => liste,
    andakiler: (t, pencere) => S.andakiYorumlar(liste, t, pencere),
    dahaFazla: () => partileriYukle(5)
  };
})();

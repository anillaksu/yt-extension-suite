/**
 * Zen Cinema — uygulamalı tur. Hoş geldin sayfası `turBekliyor` kaydını bırakır ve tur videosunu açar;
 * bu betik videoda küçük bir rehber kartıyla kullanıcıyı altı adımda yürütür.
 * Her adım, kullanıcı o işi GERÇEKTEN yapınca ilerler (olaylar: sinema, kaydedildi, panel, anlarIstendi).
 * Sayfa yenilenirse kaldığı adımdan sürer; 30 dk sonra kendiliğinden düşer.
 */
(function () {
  'use strict';
  const ZC = globalThis.ZC;
  const t = ZC.t;
  const TUR_VIDEO = 'aircAruvnKk';
  const OMUR = 30 * 60 * 1000;
  const mac = /Mac/i.test(navigator.platform || '');
  const tus = (m) => (mac ? m.replace(/Alt\s?\+\s?/g, '⌥') : m);

  // bekle: hangi olay; kosul: olayın verisi bu adımı tamamlar mı.
  const ADIMLAR = [
    { k: 'tur1', yedekB: 'Sinemaya geç', yedekM: "Alt+C'ye bas ya da sağ alttaki Sinema düğmesine tıkla.", hedef: '.aksiyon [data-is="sinema"]', bekle: 'sinema', kosul: (v) => v === true },
    { k: 'tur2', yedekB: 'Bir not al', yedekM: "Alt+N'ye bas, aklındakini yaz, Enter ile kaydet.", hedef: '.aksiyon [data-is="not"]', bekle: 'kaydedildi', kosul: (v) => v === 'not' },
    { k: 'tur3', yedekB: 'Kareyi yakala', yedekM: 'Ekrandaki görüntüyü deftere eklemek için Alt+S.', hedef: '.aksiyon [data-is="kare"]', bekle: 'kaydedildi', kosul: (v) => v === 'kare' },
    { k: 'tur4', yedekB: 'Altyazıyı sakla', yedekM: 'Alt+T şu an söylenen cümleyi kaydeder. Altyazı kapalıysa önce açar; konuşma görününce bir daha bas.', hedef: '.aksiyon [data-is="altyazi"]', bekle: 'kaydedildi', kosul: (v) => v === 'altyazi' },
    { k: 'tur5', yedekB: 'Defterini aç', yedekM: 'Alttaki Defter düğmesine tıkla. Bir zamana tıklarsan video o saniyeye döner.', hedef: '.aksiyon [data-is="panel"]', bekle: 'panel', kosul: (v) => v === true },
    { k: 'tur6', yedekB: 'Anlara bak', yedekM: 'Anlar sekmesi: yorumlarda geçen zaman damgaları. Birine tıkla, video oraya gider.', hedef: '.sekmeler [data-sekme="anlar"]', bekle: 'anlarIstendi', kosul: () => true },
    { k: 'tur7', yedekB: 'Hazırsın', yedekM: 'Her videoda aynı tuşlar. Tüm defterlerin araç çubuğundaki Zen Cinema simgesinde.', son: true }
  ];
  const TOPLAM = ADIMLAR.length - 1;

  let aktif = false, adim = 0, ilerliyor = false, reklamda = false;

  function goster(basari) {
    const a = ADIMLAR[adim];
    if (reklamda && a.bekle === 'kaydedildi') {
      // Reklam sırasında kayıt alınmaz; kullanıcı tuşun bozuk olduğunu sanmasın.
      ZC.ui.turGoster({ adim: adim + 1, toplam: TOPLAM, baslik: t('turReklamB', 'Kısa bir ara'),
        metin: t('turReklamM', 'YouTube reklamı oynuyor. Bitince bu adımla devam ederiz.'), hedef: null, son: false });
      return;
    }
    ZC.ui.turGoster({ adim: adim + 1, toplam: TOPLAM, baslik: t(a.k + 'B', a.yedekB), metin: tus(t(a.k + 'M', a.yedekM)), hedef: a.hedef, son: !!a.son, basari });
  }

  async function sakla() {
    try { await chrome.storage.local.set({ turBekliyor: { videoId: TUR_VIDEO, zaman: Date.now(), adim } }); } catch (e) { /* bağlam koptu: tur bu sayfada sürer */ }
  }

  function ilerle() {
    if (!aktif || ilerliyor) return;
    ilerliyor = true;
    // Başarıyı kısa an göster (✓), sonra sonraki adım.
    goster(true);
    setTimeout(() => {
      ilerliyor = false;
      adim++;
      if (adim >= ADIMLAR.length) { bitir(); return; }
      // Panel adımına gelindiğinde panel zaten açıksa doğrudan geç.
      goster(false);
      sakla();
    }, 900);
  }

  function bitir() {
    aktif = false;
    ZC.ui.turGizle();
    try { chrome.storage.local.remove('turBekliyor'); } catch (e) { /* bağlam koptu */ }
  }

  ['sinema', 'kaydedildi', 'panel', 'anlarIstendi'].forEach((olay) => ZC.on(olay, (veri) => {
    if (!aktif || ilerliyor) return;
    const a = ADIMLAR[adim];
    if (a.bekle === olay && a.kosul(veri)) ilerle();
  }));
  ZC.on('tur', (is) => {
    if (!aktif) return;
    if (is === 'atla') { if (!ADIMLAR[adim].son) { adim++; goster(false); sakla(); } }
    else if (is === 'kapat') bitir();
    else if (is === 'defterler') { ZC.mesaj('DEFTERLERI_AC'); bitir(); }
  });
  // Tur sinemayı kapatırsa (Alt+C) kart normal moda göre yeniden konumlanır; adım değişmez.
  ZC.on('sinema', () => { if (aktif && !ilerliyor) setTimeout(() => aktif && goster(false), 50); });

  setInterval(() => {
    if (!aktif || ilerliyor) return;
    const simdi = ZC.reklamVar();
    if (simdi === reklamda) return;
    reklamda = simdi;
    // Kart yalnız kayıt adımlarında değişir; diğer adımlarda boşuna yeniden çizilip titremesin.
    if (ADIMLAR[adim].bekle === 'kaydedildi') goster(false);
  }, 800);

  async function sayfaDegisti() {
    if (aktif && ZC.videoId() !== TUR_VIDEO) bitir();
    if (aktif || ZC.videoId() !== TUR_VIDEO) return;
    let kayit;
    try { kayit = (await chrome.storage.local.get('turBekliyor')).turBekliyor; } catch (e) { return; }
    if (!kayit || kayit.videoId !== TUR_VIDEO || Date.now() - kayit.zaman > OMUR) return;
    await ZC.ogeBekle('#movie_player video', 10000);
    for (let i = 0; i < 40 && !(ZC.ui && ZC.ui.hazir()); i++) await ZC.bekle(150);
    await ZC.bekle(1200); // oynatıcı düğmeleri ve eylem çubuğu yerleşsin
    aktif = true;
    adim = Math.min(Number(kayit.adim) || 0, ADIMLAR.length - 1);
    if (adim === 0 && ZC.sinema && ZC.sinema.acikMi()) adim = 1;
    goster(false);
  }
  document.addEventListener('yt-navigate-finish', sayfaDegisti);
  if (document.readyState !== 'loading') sayfaDegisti();
  else document.addEventListener('DOMContentLoaded', sayfaDegisti);

  ZC.tur = { aktif: () => aktif && ZC.videoId() === TUR_VIDEO };
})();

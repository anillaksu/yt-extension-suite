/**
 * Zen Cinema — altyazı satırı.
 * Yalnız ekranda kullanıcıya o an GÖSTERİLEN altyazıyı okur (.ytp-caption-segment).
 * Ağ isteği yok, YouTube'un belgesiz iç uç noktaları (timedtext vb.) kullanılmaz:
 * resmi API başkasının videosunun altyazısını vermiyor (captions.download düzenleme yetkisi ister)
 * ve belgesiz uç noktalar YouTube Developer Policies III.D.7 ile yasak. Ölçüm: oynatıcının kendi
 * POT'lu adresi tekrar çekildiğinde boş dönüyor (06.10.2026).
 */
(function () {
  'use strict';
  const ZC = globalThis.ZC;

  function ekrandaki() {
    const parcalar = [...document.querySelectorAll('#movie_player .ytp-caption-window-container .ytp-caption-segment')]
      .map((s) => (s.textContent || '').trim())
      .filter(Boolean);
    return parcalar.join(' ').replace(/\s+/g, ' ').trim();
  }

  const ccDugmesi = () => document.querySelector('#movie_player .ytp-subtitles-button');
  const ccAcik = () => { const b = ccDugmesi(); return !!(b && b.getAttribute('aria-pressed') === 'true'); };

  /**
   * Kullanıcının isteğiyle (Alt+T) çağrılır. CC kapalıysa açar ve bir satırın görünmesini bekler.
   * @returns {Promise<{metin: string|null, ccAcildi: boolean, ccYok: boolean}>}
   */
  async function satirAl(zamanAsimi) {
    let metin = ekrandaki();
    if (metin) return { metin, ccAcildi: false, ccYok: false };
    const b = ccDugmesi();
    if (!b || b.getAttribute('aria-disabled') === 'true') return { metin: null, ccAcildi: false, ccYok: true };
    let ccAcildi = false;
    if (!ccAcik()) { b.click(); ccAcildi = true; }
    const son = Date.now() + (zamanAsimi || 3000);
    while (Date.now() < son) {
      await ZC.bekle(150);
      metin = ekrandaki();
      if (metin) break;
    }
    return { metin: metin || null, ccAcildi, ccYok: false };
  }

  ZC.altyazi = { ekrandaki, satirAl, ccAcik };
})();

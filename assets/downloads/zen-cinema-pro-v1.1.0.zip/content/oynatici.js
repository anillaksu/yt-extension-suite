/**
 * Zen Cinema — oynatıcı köprüsü (sayfa/MAIN dünyası).
 * YALNIZ YouTube'un BELGELİ oynatıcı metodlarını çağırır: seekTo, pauseVideo, playVideo
 * (https://developers.google.com/youtube/iframe_api_reference#Playback_controls).
 * Neden gerekli: <video>.currentTime'ı doğrudan değiştirmek YouTube'un akış yönetimini bozuyor
 * (06.10.2026 ölçümü: eklentisiz atama yok sayıldı, eklentili akış takıldı). Belgeli seekTo bu
 * metodlara yalnız sayfa dünyasından erişilebildiği için bu küçük köprü var. Veri okumaz, ağa dokunmaz.
 */
(function () {
  'use strict';
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.zc !== 'oynatici') return;
    const p = document.getElementById('movie_player');
    if (!p) return;
    const { komut, t } = e.data;
    if (komut === 'git' && typeof p.seekTo === 'function' && Number.isFinite(t)) p.seekTo(Math.max(0, t), true);
    else if (komut === 'durdur' && typeof p.pauseVideo === 'function') p.pauseVideo();
    else if (komut === 'oynat' && typeof p.playVideo === 'function') p.playVideo();
  });
})();

/**
 * Zen Cinema — içerik betikleri ortak katmanı (ISOLATED dünya).
 * Tüm içerik dosyaları globalThis.ZC ad alanını paylaşır (aynı eklentinin içerik betikleri tek global'dedir).
 */
(function () {
  'use strict';
  const ZC = (globalThis.ZC = globalThis.ZC || {});
  ZC.saf = globalThis.ZCSaf;

  ZC.t = function (anahtar, yedek) {
    try {
      const m = chrome.i18n.getMessage(anahtar);
      if (m) return m;
    } catch (e) { /* eklenti yeniden yüklendiyse bağlam geçersiz olabilir */ }
    return yedek || anahtar;
  };

  ZC.izleSayfasi = () => location.pathname === '/watch';
  ZC.videoId = () => new URLSearchParams(location.search).get('v');
  ZC.video = () => document.querySelector('#movie_player video.html5-main-video') || document.querySelector('#movie_player video');

  // Arka plana mesaj; eklenti güncellenip bağlam koptuysa sessizce değil, açık hatayla döner.
  ZC.mesaj = function (eylem, veri) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(Object.assign({ eylem }, veri || {}), (cevap) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, hata: chrome.runtime.lastError.message });
            return;
          }
          resolve(cevap || { ok: false, hata: 'Boş cevap' });
        });
      } catch (e) {
        resolve({ ok: false, hata: 'Eklenti yeniden yüklendi; sayfayı yenileyin.' });
      }
    });
  };

  // Görünen sayfadan video başlığı ve kanal (oynatıcının belgesiz iç nesnesi okunmaz).
  ZC.videoBilgisi = function () {
    const baslik = (document.querySelector('ytd-watch-metadata h1 yt-formatted-string, ytd-watch-metadata #title h1')?.textContent || '')
      .trim() || document.title.replace(/^\(\d+\)\s*/, '').replace(/ - YouTube$/, '').trim();
    const kanal = (document.querySelector('ytd-watch-metadata ytd-channel-name a, #owner ytd-channel-name a')?.textContent || '').trim();
    return { id: ZC.videoId(), baslik, kanal };
  };

  ZC.bekle = (ms) => new Promise((r) => setTimeout(r, ms));

  // Seçici görünene kadar bekle (en çok zamanAsimi ms).
  ZC.ogeBekle = function (secici, zamanAsimi, kok) {
    const k = kok || document;
    const var_ = k.querySelector(secici);
    if (var_) return Promise.resolve(var_);
    return new Promise((resolve) => {
      const g = new MutationObserver(() => {
        const o = k.querySelector(secici);
        if (o) { g.disconnect(); clearTimeout(z); resolve(o); }
      });
      g.observe(k === document ? document.documentElement : k, { childList: true, subtree: true });
      const z = setTimeout(() => { g.disconnect(); resolve(null); }, zamanAsimi || 5000);
    });
  };

  // YouTube reklam oynatırken <video> reklamın kendisidir; zaman ve kare videoya ait olmaz.
  // Yalnız okunur, reklama dokunulmaz.
  ZC.reklamVar = () => !!document.querySelector('#movie_player.ad-showing');

  // Oynatıcı kontrolü belgeli YouTube metodlarıyla (content/oynatici.js köprüsü).
  // <video>.currentTime/pause/play doğrudan kullanılmaz: YouTube'un akış yönetimini bozuyor (ölçüldü).
  ZC.oynatici = (komut, t) => window.postMessage({ zc: 'oynatici', komut, t }, '*');
  ZC.videyaGit = (saniye) => ZC.oynatici('git', Math.max(0, Number(saniye) || 0));

  // Basit olay yolu: modüller birbirine doğrudan bağlanmasın.
  const dinleyiciler = {};
  ZC.on = (ad, fn) => { (dinleyiciler[ad] = dinleyiciler[ad] || []).push(fn); };
  ZC.yay = (ad, veri) => { (dinleyiciler[ad] || []).forEach((fn) => { try { fn(veri); } catch (e) { console.warn('[ZenCinema]', ad, e); } }); };
})();

/**
 * Zen Cinema — sayfa-içi sinema modu.
 * YouTube'un kendi oynatıcısı tiyatro moduna alınır, kabı sabit sahneye dönüşür,
 * çevresi görünmez olur. Video 3 sn fare hareketsiz kalınca arayüz susar.
 */
(function () {
  'use strict';
  const ZC = globalThis.ZC;
  let acik = false;
  let tiyatroyuBizActik = false;
  let sukunZaman = null;

  const flexy = () => document.querySelector('ytd-watch-flexy');
  const tiyatroMu = () => { const f = flexy(); return !!(f && f.hasAttribute('theater')); };

  function yenidenBoyutla() {
    // Oynatıcı yerleşimini yeni kaba göre yeniden hesaplasın.
    [30, 250, 600].forEach((ms) => setTimeout(() => window.dispatchEvent(new Event('resize')), ms));
  }

  // Sahne kabının boyutu her değiştiğinde (panel açılışı, geçiş animasyonu, pencere) oynatıcıya haber ver.
  // Sabit zamanlayıcılar yavaş makinede geçişin bitişini kaçırabiliyordu (ölçüldü: panel açık, oynatıcı eski genişlikte).
  let sahneGozcu = null, sahneZaman = null;
  function sahneyiIzle() {
    const kap = document.querySelector('ytd-watch-flexy #full-bleed-container');
    if (!kap || typeof ResizeObserver === 'undefined') return;
    if (sahneGozcu) sahneGozcu.disconnect();
    sahneGozcu = new ResizeObserver(() => {
      if (!acik) return;
      clearTimeout(sahneZaman);
      sahneZaman = setTimeout(() => window.dispatchEvent(new Event('resize')), 60);
    });
    sahneGozcu.observe(kap);
  }

  async function tiyatroyaAl() {
    if (tiyatroMu()) return true;
    const btn = document.querySelector('.ytp-size-button');
    if (!btn) return false;
    btn.click();
    for (let i = 0; i < 15; i++) {
      await ZC.bekle(100);
      if (tiyatroMu()) { tiyatroyuBizActik = true; return true; }
    }
    return false;
  }

  function tiyatrodanCik() {
    if (tiyatroyuBizActik && tiyatroMu()) {
      const btn = document.querySelector('.ytp-size-button');
      if (btn) btn.click();
    }
    tiyatroyuBizActik = false;
  }

  async function ac() {
    if (!ZC.izleSayfasi()) return;
    const tamam = await tiyatroyaAl();
    if (!tamam) {
      ZC.yay('bildirim', ZC.t('zcTiyatroYok', 'Sinema modu bu sayfa düzeninde açılamadı.'));
      return;
    }
    acik = true;
    document.documentElement.classList.add('zc-on');
    sahneyiIzle();
    yenidenBoyutla();
    sukunuKur();
    ZC.yay('sinema', true);
  }

  function kapat() {
    acik = false;
    document.documentElement.classList.remove('zc-on', 'zc-sukun');
    clearTimeout(sukunZaman);
    if (sahneGozcu) { sahneGozcu.disconnect(); sahneGozcu = null; }
    tiyatrodanCik();
    yenidenBoyutla();
    ZC.yay('sinema', false);
  }

  function degistir() { return acik ? kapat() : ac(); }

  // --- Sükunet: fare durunca arayüz susar ---
  function sukunuKur() {
    document.documentElement.classList.remove('zc-sukun');
    ZC.yay('sukun', false);
    clearTimeout(sukunZaman);
    if (!acik) return;
    sukunZaman = setTimeout(() => {
      const v = ZC.video();
      const oynuyor = v && !v.paused;
      if (acik && oynuyor && !ZC.yaziyorMu()) {
        document.documentElement.classList.add('zc-sukun');
        ZC.yay('sukun', true);
      }
    }, 3000);
  }
  ['mousemove', 'mousedown', 'wheel', 'keydown'].forEach((ad) =>
    document.addEventListener(ad, () => { if (acik) sukunuKur(); }, { passive: true, capture: true })
  );

  // Yazı alanındayken kısayol ve sükunet devreye girmez (gölge DOM içi dahil).
  ZC.yaziyorMu = function (olay) {
    const hedef = olay && olay.composedPath ? olay.composedPath()[0] : (document.activeElement && document.activeElement.shadowRoot
      ? document.activeElement.shadowRoot.activeElement : document.activeElement);
    if (!hedef || !hedef.tagName) return false;
    return hedef.tagName === 'INPUT' || hedef.tagName === 'TEXTAREA' || hedef.isContentEditable;
  };

  // --- Oynatıcıya aç/kapa düğmesi ---
  function oyuncuDugmesi() {
    if (!ZC.izleSayfasi() || document.querySelector('.zc-oyuncu-dugme')) return;
    const sag = document.querySelector('#movie_player .ytp-right-controls');
    if (!sag) return;
    const b = document.createElement('button');
    b.className = 'ytp-button zc-oyuncu-dugme';
    b.title = ZC.t('zcDugmeIpucu', 'Zen Cinema (Alt+C)');
    b.setAttribute('aria-label', b.title);
    b.innerHTML = '<svg viewBox="0 0 36 36" fill="none" stroke="#fff" stroke-width="2">' +
      '<rect x="8" y="11" width="20" height="14" rx="3"/>' +
      '<circle class="zc-nokta" cx="18" cy="18" r="2.6" fill="#fff" stroke="none"/></svg>';
    b.addEventListener('click', (e) => { e.stopPropagation(); degistir(); });
    sag.insertBefore(b, sag.firstChild);
  }

  // --- Klavye: Alt+C ---
  window.addEventListener('keydown', (e) => {
    if (!ZC.izleSayfasi() || ZC.yaziyorMu(e)) return;
    if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyC') {
      e.preventDefault();
      e.stopPropagation();
      degistir();
    }
  }, true);

  // --- YouTube tek sayfa uygulaması: her gezinmede yeniden uygula ---
  async function sayfaDegisti() {
    if (!ZC.izleSayfasi()) {
      if (acik) kapat();
      return;
    }
    await ZC.ogeBekle('#movie_player .ytp-right-controls', 8000);
    oyuncuDugmesi();
    if (acik) {
      // Yeni video: kap ve tiyatro durumu sıfırlanmış olabilir.
      await tiyatroyaAl();
      document.documentElement.classList.add('zc-on');
      sahneyiIzle();
      yenidenBoyutla();
      return;
    }
    try {
      const { sinemaOtomatik } = await chrome.storage.local.get('sinemaOtomatik');
      if (sinemaOtomatik) ac();
    } catch (e) { /* bağlam koptu: sayfa yenilenince düzelir */ }
  }
  document.addEventListener('yt-navigate-finish', sayfaDegisti);
  if (document.readyState !== 'loading') sayfaDegisti();
  else document.addEventListener('DOMContentLoaded', sayfaDegisti);

  // Popup'tan aç/kapa.
  chrome.runtime.onMessage.addListener((m, _g, cevap) => {
    if (m && m.eylem === 'SINEMA_DEGISTIR') { degistir(); cevap({ ok: true }); }
    if (m && m.eylem === 'SINEMA_DURUM') { cevap({ ok: true, acik, izleSayfasi: ZC.izleSayfasi() }); }
  });

  ZC.sinema = { ac, kapat, degistir, acikMi: () => acik, sahneGenisliginiAyarla: (px) => {
    document.documentElement.style.setProperty('--zc-sag', (px || 0) + 'px');
    yenidenBoyutla();
  } };
})();

/**
 * Zen Cinema — saf yardımcılar (DOM'suz; içerik betikleri, defter sayfası ve node testleri ortak kullanır).
 */
(function () {
  'use strict';

  function zamanBicim(saniye) {
    const s = Math.max(0, Math.floor(saniye || 0));
    const sa = Math.floor(s / 3600);
    const dk = Math.floor((s % 3600) / 60);
    const sn = s % 60;
    const iki = (n) => String(n).padStart(2, '0');
    return sa > 0 ? `${sa}:${iki(dk)}:${iki(sn)}` : `${iki(dk)}:${iki(sn)}`;
  }

  // "1:02:03" / "12:34" → saniye; geçersizse null.
  function zamanCoz(metin) {
    const m = String(metin || '').trim().match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
    if (!m) return null;
    if (m[3] !== undefined) {
      const sa = +m[1], dk = +m[2], sn = +m[3];
      if (dk > 59 || sn > 59) return null;
      return sa * 3600 + dk * 60 + sn;
    }
    const dk = +m[1], sn = +m[2];
    if (sn > 59) return null;
    return dk * 60 + sn;
  }

  // Yorum metnindeki tüm zaman damgaları (tekrarsız, sıralı). Video süresini aşanlar atılır.
  function metindekiZamanlar(metin, sure) {
    const sonuc = new Set();
    const re = /(?:^|[^\d:])(\d{1,2}:\d{2}(?::\d{2})?)(?![\d:])/g;
    let m;
    const s = String(metin || '');
    while ((m = re.exec(s)) !== null) {
      const t = zamanCoz(m[1]);
      if (t === null) continue;
      if (typeof sure === 'number' && sure > 0 && t > sure) continue;
      sonuc.add(t);
    }
    return [...sonuc].sort((a, b) => a - b);
  }

  // YouTube bağlantısındaki t parametresi: "t=95", "t=95s", "t=1m35s", "t=1h2m3s".
  function hreftenZaman(href) {
    const m = String(href || '').match(/[?&#]t=([0-9hms]+)/);
    if (!m) return null;
    const v = m[1];
    if (/^\d+s?$/.test(v)) return parseInt(v, 10);
    const p = v.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/);
    if (!p || (!p[1] && !p[2] && !p[3])) return null;
    return (+(p[1] || 0)) * 3600 + (+(p[2] || 0)) * 60 + (+(p[3] || 0));
  }

  // t anına ±pencere içindeki zamanlı yorumlar.
  function andakiYorumlar(yorumlar, t, pencere) {
    const w = typeof pencere === 'number' ? pencere : 5;
    return (yorumlar || []).filter((y) => Math.abs(y.t - t) <= w);
  }

  const videoBaglantisi = (videoId, t) => `https://www.youtube.com/watch?v=${videoId}` + (t ? `&t=${Math.floor(t)}s` : '');

  // Dışa aktarma dosya adı: güvenli, okunur, Türkçe karakterler korunur.
  function dosyaAdi(metin) {
    const temiz = String(metin || 'defter').replace(/[\\/:*?"<>|#%{}^~[\]`]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
    return temiz || 'defter';
  }

  // Defter → Markdown. kareAdlari: { kareId: 'images/001-00-42.jpg' }
  function defterMarkdown(defter, kareAdlari) {
    const ad = kareAdlari || {};
    const satirlar = [];
    satirlar.push(`# ${defter.baslik || defter.videoId}`, '');
    satirlar.push(`${defter.kanal ? defter.kanal + ' · ' : ''}${videoBaglantisi(defter.videoId)}`, '');
    const turAdi = { not: 'Not', kare: 'Kare', altyazi: 'Altyazı' };
    (defter.kayitlar || []).slice().sort((a, b) => a.t - b.t).forEach((k) => {
      satirlar.push(`## [${zamanBicim(k.t)}](${videoBaglantisi(defter.videoId, k.t)}) · ${turAdi[k.tur] || 'Not'}`, '');
      if (k.tur === 'altyazi') {
        if (k.metin) satirlar.push(`> ${k.metin}`, '');
      } else {
        if (k.metin) satirlar.push(k.metin, '');
        if (k.altyazi && k.altyazi !== k.metin) satirlar.push(`> ${k.altyazi}`, '');
      }
      if (k.kareId && ad[k.kareId]) satirlar.push(`![${zamanBicim(k.t)}](${ad[k.kareId]})`, '');
    });
    satirlar.push('---', '_Zen Cinema ile kaydedildi._', '');
    return satirlar.join('\n');
  }

  const api = { zamanBicim, zamanCoz, metindekiZamanlar, hreftenZaman, andakiYorumlar,
    videoBaglantisi, dosyaAdi, defterMarkdown };
  globalThis.ZCSaf = api;
})();

/**
 * Zen Cinema — Tüm defterler sayfası: listele, görüntüle, dışa aktar (Pro), sil.
 * Eklenti origin'inde çalışır; chrome.storage ve IndexedDB'ye doğrudan erişir.
 */
(function () {
  'use strict';
  const S = globalThis.ZCSaf;
  const D = globalThis.ZCDepo;
  const $ = (id) => document.getElementById(id);
  const t = (k, y) => chrome.i18n.getMessage(k) || y || k;
  const mesaj = (eylem, veri) => new Promise((r) => chrome.runtime.sendMessage(Object.assign({ eylem }, veri || {}), (c) => r(c || {})));

  let defterler = {};
  let seciliId = null;
  let pro = false;
  const urlOnbellek = new Map();

  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n, el.textContent); });
  if (new URLSearchParams(location.search).get('hosgeldin')) $('hosgeldin').hidden = false;

  function el(etiket, sinif, metin) {
    const e = document.createElement(etiket);
    if (sinif) e.className = sinif;
    if (metin !== undefined) e.textContent = metin;
    return e;
  }

  async function kareUrl(kareId) {
    if (urlOnbellek.has(kareId)) return urlOnbellek.get(kareId);
    const blob = await D.kareOku(kareId);
    const url = blob ? URL.createObjectURL(blob) : null;
    urlOnbellek.set(kareId, url);
    return url;
  }

  function sirali() {
    return Object.values(defterler).sort((a, b) => (b.guncelleme || 0) - (a.guncelleme || 0));
  }

  function listeCiz() {
    const liste = $('liste');
    liste.textContent = '';
    sirali().forEach((d) => {
      const b = el('button', 'defter-ogesi' + (d.videoId === seciliId ? ' secili' : ''));
      b.appendChild(el('b', '', d.baslik || d.videoId));
      const tarih = new Date(d.guncelleme || d.olusturma || Date.now()).toLocaleDateString();
      b.appendChild(el('small', '', `${d.kayitlar.length} ${t('dfKayit', 'entries')} · ${tarih}`));
      b.addEventListener('click', () => { seciliId = d.videoId; listeCiz(); icerikCiz(); });
      liste.appendChild(b);
    });
  }

  async function icerikCiz() {
    const kap = $('icerik');
    kap.textContent = '';
    const d = defterler[seciliId];
    if (!d) {
      kap.appendChild(el('div', 'bos', t('dfBos', 'No notebooks yet. Open a YouTube video and press Alt+N.')));
      return;
    }
    const bas = el('div', 'icerik-bas');
    const sol = el('div');
    sol.appendChild(el('h2', '', d.baslik || d.videoId));
    const link = el('a', '', (d.kanal ? d.kanal + ' · ' : '') + t('dfVideoyuAc', 'Open video ↗'));
    link.href = S.videoBaglantisi(d.videoId);
    link.target = '_blank';
    link.rel = 'noopener';
    sol.appendChild(link);
    bas.appendChild(sol);

    const eylemler = el('div', 'eylemler');
    const md = el('button', 'dugme birincil', t('dfMarkdown', 'Markdown + images (ZIP)'));
    const pdf = el('button', 'dugme', t('dfPdf', 'Print / PDF'));
    if (!pro) [md, pdf].forEach((b) => { const k = el('span', 'kilit', 'PRO'); b.appendChild(k); });
    md.addEventListener('click', () => (pro ? zipIndir(d) : teklifGoster()));
    pdf.addEventListener('click', () => (pro ? yazdir(d) : teklifGoster()));
    const sil = el('button', 'dugme tehlike', t('dfSil', 'Delete'));
    sil.addEventListener('click', async () => {
      if (!confirm(t('dfSilOnay', 'Delete this notebook and its images?'))) return;
      await mesaj('DEFTER_SIL', { videoId: d.videoId });
      await yukle();
    });
    eylemler.append(md, pdf, sil);
    bas.appendChild(eylemler);
    kap.appendChild(bas);

    const kayitlar = el('div', 'kayitlar');
    const turAdi = { not: t('zcNot', 'Note'), kare: t('zcKare', 'Frame'), altyazi: t('zcAltyazi', 'Caption') };
    for (const k of d.kayitlar.slice().sort((a, b) => a.t - b.t)) {
      const satir = el('div', 'kayit');
      const z = el('a', 'zaman', S.zamanBicim(k.t));
      z.href = S.videoBaglantisi(d.videoId, k.t);
      z.target = '_blank';
      z.rel = 'noopener';
      satir.appendChild(z);
      const govde = el('div');
      govde.appendChild(el('div', 'tur', turAdi[k.tur] || turAdi.not));
      if (k.tur === 'altyazi') govde.appendChild(el('blockquote', '', k.metin));
      else {
        if (k.metin) govde.appendChild(el('p', '', k.metin));
        if (k.altyazi && k.altyazi !== k.metin) govde.appendChild(el('blockquote', '', k.altyazi));
      }
      if (k.kareId) {
        const img = el('img');
        img.alt = S.zamanBicim(k.t);
        kareUrl(k.kareId).then((u) => { if (u) img.src = u; });
        govde.appendChild(img);
      }
      satir.appendChild(govde);
      kayitlar.appendChild(satir);
    }
    kap.appendChild(kayitlar);
  }

  function indir(veri, ad, tur) {
    const url = URL.createObjectURL(new Blob([veri], { type: tur }));
    const a = el('a');
    a.href = url;
    a.download = ad;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function zipIndir(d) {
    const dosyalar = [];
    const kareAdlari = {};
    let sira = 0;
    for (const k of d.kayitlar.slice().sort((a, b) => a.t - b.t)) {
      if (!k.kareId) continue;
      const blob = await D.kareOku(k.kareId);
      if (!blob) continue;
      sira++;
      const ad = `images/${String(sira).padStart(3, '0')}-${S.zamanBicim(k.t).replace(/:/g, '-')}.jpg`;
      kareAdlari[k.kareId] = ad;
      dosyalar.push({ ad, veri: new Uint8Array(await blob.arrayBuffer()) });
    }
    dosyalar.unshift({ ad: 'notes.md', veri: S.defterMarkdown(d, kareAdlari) });
    indir(globalThis.ZCZip.olustur(dosyalar), `${S.dosyaAdi(d.baslik)} - Zen Cinema.zip`, 'application/zip');
  }

  async function yazdir(d) {
    const kap = $('yazdir');
    kap.textContent = '';
    kap.appendChild(el('h1', '', d.baslik || d.videoId));
    kap.appendChild(el('div', 'kaynak', (d.kanal ? d.kanal + ' · ' : '') + S.videoBaglantisi(d.videoId)));
    const yuklemeler = [];
    for (const k of d.kayitlar.slice().sort((a, b) => a.t - b.t)) {
      const blok = el('div', 'p-kayit');
      blok.appendChild(el('div', 'p-zaman', S.zamanBicim(k.t)));
      if (k.tur === 'altyazi') blok.appendChild(el('blockquote', '', k.metin));
      else {
        if (k.metin) blok.appendChild(el('p', '', k.metin));
        if (k.altyazi && k.altyazi !== k.metin) blok.appendChild(el('blockquote', '', k.altyazi));
      }
      if (k.kareId) {
        const img = el('img');
        yuklemeler.push(kareUrl(k.kareId).then((u) => new Promise((r) => {
          if (!u) return r();
          img.onload = img.onerror = () => r();
          img.src = u;
        })));
        blok.appendChild(img);
      }
      kap.appendChild(blok);
    }
    await Promise.all(yuklemeler);
    window.print();
  }

  function teklifGoster() { $('teklif').hidden = false; }
  $('teklif-kapat').addEventListener('click', () => { $('teklif').hidden = true; });
  $('teklif-al').addEventListener('click', () => { mesaj('SATIN_AL'); $('teklif').hidden = true; });

  async function yukle() {
    const durum = await mesaj('DURUM');
    pro = !!durum.pro;
    $('durum-rozet').textContent = pro ? 'PRO' : t('popUcretsiz', 'Free');
    $('durum-rozet').classList.toggle('pro', pro);
    const s = await chrome.storage.local.get('defterler');
    defterler = s.defterler || {};
    if (!defterler[seciliId]) seciliId = (sirali()[0] || {}).videoId || null;
    listeCiz();
    await icerikCiz();
  }

  chrome.storage.onChanged.addListener((d, alan) => { if (alan === 'local' && (d.defterler || d.isPro)) yukle(); });
  yukle();
})();
